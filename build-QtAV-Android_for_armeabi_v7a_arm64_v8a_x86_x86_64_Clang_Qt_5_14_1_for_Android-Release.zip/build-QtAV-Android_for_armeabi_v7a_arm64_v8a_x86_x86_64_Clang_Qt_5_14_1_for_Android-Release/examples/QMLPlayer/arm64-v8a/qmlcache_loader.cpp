#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>

static const unsigned char qt_resource_tree[] = {
0,
0,0,0,0,2,0,0,0,1,0,0,0,1,0,0,0,
8,0,2,0,0,0,1,0,0,0,2,0,0,0,20,0,
2,0,0,0,18,0,0,0,3,0,0,0,148,0,0,0,
0,0,1,0,0,0,0,0,0,1,36,0,0,0,0,0,
1,0,0,0,0,0,0,1,94,0,0,0,0,0,1,0,
0,0,0,0,0,1,178,0,0,0,0,0,1,0,0,0,
0,0,0,1,218,0,0,0,0,0,1,0,0,0,0,0,
0,0,230,0,0,0,0,0,1,0,0,0,0,0,0,1,
132,0,0,0,0,0,1,0,0,0,0,0,0,1,156,0,
0,0,0,0,1,0,0,0,0,0,0,0,186,0,0,0,
0,0,1,0,0,0,0,0,0,0,122,0,0,0,0,0,
1,0,0,0,0,0,0,0,208,0,0,0,0,0,1,0,
0,0,0,0,0,2,66,0,0,0,0,0,1,0,0,0,
0,0,0,1,72,0,0,0,0,0,1,0,0,0,0,0,
0,0,82,0,0,0,0,0,1,0,0,0,0,0,0,0,
44,0,0,0,0,0,1,0,0,0,0,0,0,2,30,0,
0,0,0,0,1,0,0,0,0,0,0,1,6,0,0,0,
0,0,1,0,0,0,0,0,0,1,252,0,0,0,0,0,
1,0,0,0,0};
static const unsigned char qt_resource_names[] = {
0,
1,0,0,0,47,0,47,0,3,0,0,120,60,0,113,0,
109,0,108,0,9,1,114,35,130,0,81,0,77,0,76,0,
80,0,108,0,97,0,121,0,101,0,114,0,16,13,31,180,
156,0,68,0,101,0,108,0,101,0,103,0,97,0,116,0,
101,0,73,0,116,0,101,0,109,0,46,0,113,0,109,0,
108,0,17,13,19,23,60,0,77,0,101,0,100,0,105,0,
97,0,73,0,110,0,102,0,111,0,80,0,97,0,103,0,
101,0,46,0,113,0,109,0,108,0,10,10,206,21,220,0,
83,0,108,0,105,0,100,0,101,0,114,0,46,0,113,0,
109,0,108,0,16,1,216,174,156,0,83,0,117,0,98,0,
116,0,105,0,116,0,108,0,101,0,80,0,97,0,103,0,
101,0,46,0,113,0,109,0,108,0,8,8,1,90,92,0,
109,0,97,0,105,0,110,0,46,0,113,0,109,0,108,0,
8,11,3,106,147,0,117,0,116,0,105,0,108,0,115,0,
46,0,106,0,115,0,13,6,162,97,220,0,65,0,117,0,
100,0,105,0,111,0,80,0,97,0,103,0,101,0,46,0,
113,0,109,0,108,0,12,13,89,104,252,0,77,0,105,0,
115,0,99,0,80,0,97,0,103,0,101,0,46,0,113,0,
109,0,108,0,15,3,85,158,156,0,80,0,114,0,111,0,
103,0,114,0,101,0,115,0,115,0,66,0,97,0,114,0,
46,0,113,0,109,0,108,0,8,12,88,94,92,0,77,0,
101,0,110,0,117,0,46,0,113,0,109,0,108,0,16,3,
129,229,220,0,67,0,111,0,110,0,116,0,114,0,111,0,
108,0,80,0,97,0,110,0,101,0,108,0,46,0,113,0,
109,0,108,0,9,6,199,219,28,0,65,0,98,0,111,0,
117,0,116,0,46,0,113,0,109,0,108,0,8,7,216,94,
252,0,80,0,97,0,103,0,101,0,46,0,113,0,109,0,
108,0,17,3,246,219,188,0,80,0,108,0,97,0,121,0,
76,0,105,0,115,0,116,0,80,0,97,0,110,0,101,0,
108,0,46,0,113,0,109,0,108,0,14,5,238,63,188,0,
86,0,105,0,100,0,101,0,111,0,67,0,111,0,100,0,
101,0,99,0,46,0,113,0,109,0,108,0,14,14,67,24,
28,0,69,0,102,0,102,0,101,0,99,0,116,0,80,0,
97,0,103,0,101,0,46,0,113,0,109,0,108,0,15,13,
33,245,188,0,67,0,111,0,110,0,102,0,105,0,103,0,
80,0,97,0,110,0,101,0,108,0,46,0,113,0,109,0,
108,0,10,11,104,113,92,0,66,0,117,0,116,0,116,0,
111,0,110,0,46,0,113,0,109,0,108};
static const unsigned char qt_resource_empty_payout[] = { 0, 0, 0, 0, 0 };
QT_BEGIN_NAMESPACE
extern Q_CORE_EXPORT bool qRegisterResourceData(int, const unsigned char *, const unsigned char *, const unsigned char *);
QT_END_NAMESPACE
namespace QmlCacheGeneratedCode {
namespace _qml_QMLPlayer_Button_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_ConfigPanel_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_EffectPage_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_VideoCodec_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_PlayListPanel_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_Page_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_About_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_ControlPanel_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_Menu_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_ProgressBar_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_MiscPage_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_AudioPage_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_utils_js { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_main_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_SubtitlePage_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_Slider_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_MediaInfoPage_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_QMLPlayer_DelegateItem_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    ~Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/Button.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_Button_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/ConfigPanel.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_ConfigPanel_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/EffectPage.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_EffectPage_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/VideoCodec.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_VideoCodec_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/PlayListPanel.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_PlayListPanel_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/Page.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_Page_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/About.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_About_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/ControlPanel.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_ControlPanel_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/Menu.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_Menu_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/ProgressBar.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_ProgressBar_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/MiscPage.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_MiscPage_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/AudioPage.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_AudioPage_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/utils.js"), &QmlCacheGeneratedCode::_qml_QMLPlayer_utils_js::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/main.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_main_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/SubtitlePage.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_SubtitlePage_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/Slider.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_Slider_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/MediaInfoPage.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_MediaInfoPage_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/QMLPlayer/DelegateItem.qml"), &QmlCacheGeneratedCode::_qml_QMLPlayer_DelegateItem_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.version = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
QT_PREPEND_NAMESPACE(qRegisterResourceData)(/*version*/0x01, qt_resource_tree, qt_resource_names, qt_resource_empty_payout);
}

Registry::~Registry() {
    QQmlPrivate::qmlunregister(QQmlPrivate::QmlUnitCacheHookRegistration, quintptr(&lookupCachedUnit));
}

const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_qmlplayer)() {
    ::unitRegistry();
    Q_INIT_RESOURCE(qmlplayer_qmlcache);
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_qmlplayer))
int QT_MANGLE_NAMESPACE(qCleanupResources_qmlplayer)() {
    Q_CLEANUP_RESOURCE(qmlplayer_qmlcache);
    return 1;
}
