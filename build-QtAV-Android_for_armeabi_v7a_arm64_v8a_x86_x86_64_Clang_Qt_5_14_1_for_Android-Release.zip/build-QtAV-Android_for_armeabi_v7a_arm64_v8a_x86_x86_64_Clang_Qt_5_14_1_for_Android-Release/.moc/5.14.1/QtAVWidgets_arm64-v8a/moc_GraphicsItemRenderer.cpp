/****************************************************************************
** Meta object code from reading C++ file 'GraphicsItemRenderer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/widgets/QtAVWidgets/GraphicsItemRenderer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GraphicsItemRenderer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtAV__GraphicsItemRenderer_t {
    QByteArrayData data[30];
    char stringdata0[472];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtAV__GraphicsItemRenderer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtAV__GraphicsItemRenderer_t qt_meta_stringdata_QtAV__GraphicsItemRenderer = {
    {
QT_MOC_LITERAL(0, 0, 26), // "QtAV::GraphicsItemRenderer"
QT_MOC_LITERAL(1, 27, 24), // "sourceAspectRatioChanged"
QT_MOC_LITERAL(2, 52, 0), // ""
QT_MOC_LITERAL(3, 53, 5), // "value"
QT_MOC_LITERAL(4, 59, 23), // "regionOfInterestChanged"
QT_MOC_LITERAL(5, 83, 21), // "outAspectRatioChanged"
QT_MOC_LITERAL(6, 105, 25), // "outAspectRatioModeChanged"
QT_MOC_LITERAL(7, 131, 17), // "brightnessChanged"
QT_MOC_LITERAL(8, 149, 15), // "contrastChanged"
QT_MOC_LITERAL(9, 165, 10), // "hueChanged"
QT_MOC_LITERAL(10, 176, 17), // "saturationChanged"
QT_MOC_LITERAL(11, 194, 22), // "backgroundColorChanged"
QT_MOC_LITERAL(12, 217, 18), // "orientationChanged"
QT_MOC_LITERAL(13, 236, 16), // "videoRectChanged"
QT_MOC_LITERAL(14, 253, 21), // "videoFrameSizeChanged"
QT_MOC_LITERAL(15, 275, 13), // "openGLChanged"
QT_MOC_LITERAL(16, 289, 6), // "opengl"
QT_MOC_LITERAL(17, 296, 10), // "brightness"
QT_MOC_LITERAL(18, 307, 8), // "contrast"
QT_MOC_LITERAL(19, 316, 3), // "hue"
QT_MOC_LITERAL(20, 320, 10), // "saturation"
QT_MOC_LITERAL(21, 331, 15), // "backgroundColor"
QT_MOC_LITERAL(22, 347, 16), // "regionOfInterest"
QT_MOC_LITERAL(23, 364, 17), // "sourceAspectRatio"
QT_MOC_LITERAL(24, 382, 14), // "outAspectRatio"
QT_MOC_LITERAL(25, 397, 18), // "outAspectRatioMode"
QT_MOC_LITERAL(26, 416, 18), // "OutAspectRatioMode"
QT_MOC_LITERAL(27, 435, 11), // "orientation"
QT_MOC_LITERAL(28, 447, 9), // "videoRect"
QT_MOC_LITERAL(29, 457, 14) // "videoFrameSize"

    },
    "QtAV::GraphicsItemRenderer\0"
    "sourceAspectRatioChanged\0\0value\0"
    "regionOfInterestChanged\0outAspectRatioChanged\0"
    "outAspectRatioModeChanged\0brightnessChanged\0"
    "contrastChanged\0hueChanged\0saturationChanged\0"
    "backgroundColorChanged\0orientationChanged\0"
    "videoRectChanged\0videoFrameSizeChanged\0"
    "openGLChanged\0opengl\0brightness\0"
    "contrast\0hue\0saturation\0backgroundColor\0"
    "regionOfInterest\0sourceAspectRatio\0"
    "outAspectRatio\0outAspectRatioMode\0"
    "OutAspectRatioMode\0orientation\0videoRect\0"
    "videoFrameSize"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtAV__GraphicsItemRenderer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
      13,  102, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   79,    2, 0x06 /* Public */,
       4,    0,   82,    2, 0x06 /* Public */,
       5,    0,   83,    2, 0x06 /* Public */,
       6,    0,   84,    2, 0x06 /* Public */,
       7,    1,   85,    2, 0x06 /* Public */,
       8,    1,   88,    2, 0x06 /* Public */,
       9,    1,   91,    2, 0x06 /* Public */,
      10,    1,   94,    2, 0x06 /* Public */,
      11,    0,   97,    2, 0x06 /* Public */,
      12,    0,   98,    2, 0x06 /* Public */,
      13,    0,   99,    2, 0x06 /* Public */,
      14,    0,  100,    2, 0x06 /* Public */,
      15,    0,  101,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      16, QMetaType::Bool, 0x00495003,
      17, QMetaType::QReal, 0x00495103,
      18, QMetaType::QReal, 0x00495103,
      19, QMetaType::QReal, 0x00495103,
      20, QMetaType::QReal, 0x00495103,
      21, QMetaType::QColor, 0x00495103,
      22, QMetaType::QRectF, 0x00495103,
      23, QMetaType::QReal, 0x00495001,
      24, QMetaType::QReal, 0x00495103,
      25, 0x80000000 | 26, 0x0049510b,
      27, QMetaType::Int, 0x00495103,
      28, QMetaType::QRect, 0x00495001,
      29, QMetaType::QSize, 0x00495001,

 // properties: notify_signal_id
      12,
       4,
       5,
       6,
       7,
       8,
       1,
       0,
       2,
       3,
       9,
      10,
      11,

 // enums: name, alias, flags, count, data

 // enum data: key, value

       0        // eod
};

void QtAV::GraphicsItemRenderer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GraphicsItemRenderer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sourceAspectRatioChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 1: _t->regionOfInterestChanged(); break;
        case 2: _t->outAspectRatioChanged(); break;
        case 3: _t->outAspectRatioModeChanged(); break;
        case 4: _t->brightnessChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 5: _t->contrastChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 6: _t->hueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 7: _t->saturationChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 8: _t->backgroundColorChanged(); break;
        case 9: _t->orientationChanged(); break;
        case 10: _t->videoRectChanged(); break;
        case 11: _t->videoFrameSizeChanged(); break;
        case 12: _t->openGLChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GraphicsItemRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::sourceAspectRatioChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::regionOfInterestChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::outAspectRatioChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::outAspectRatioModeChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::brightnessChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::contrastChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::hueChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::saturationChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::backgroundColorChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::orientationChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::videoRectChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::videoFrameSizeChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (GraphicsItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GraphicsItemRenderer::openGLChanged)) {
                *result = 12;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<GraphicsItemRenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->isOpenGL(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->brightness(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->contrast(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->hue(); break;
        case 4: *reinterpret_cast< qreal*>(_v) = _t->saturation(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->backgroundColor(); break;
        case 6: *reinterpret_cast< QRectF*>(_v) = _t->regionOfInterest(); break;
        case 7: *reinterpret_cast< qreal*>(_v) = _t->sourceAspectRatio(); break;
        case 8: *reinterpret_cast< qreal*>(_v) = _t->outAspectRatio(); break;
        case 9: *reinterpret_cast< OutAspectRatioMode*>(_v) = _t->outAspectRatioMode(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->orientation(); break;
        case 11: *reinterpret_cast< QRect*>(_v) = _t->videoRect(); break;
        case 12: *reinterpret_cast< QSize*>(_v) = _t->videoFrameSize(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<GraphicsItemRenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setOpenGL(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setBrightness(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setContrast(*reinterpret_cast< qreal*>(_v)); break;
        case 3: _t->setHue(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setSaturation(*reinterpret_cast< qreal*>(_v)); break;
        case 5: _t->setBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setRegionOfInterest(*reinterpret_cast< QRectF*>(_v)); break;
        case 8: _t->setOutAspectRatio(*reinterpret_cast< qreal*>(_v)); break;
        case 9: _t->setOutAspectRatioMode(*reinterpret_cast< OutAspectRatioMode*>(_v)); break;
        case 10: _t->setOrientation(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtAV::GraphicsItemRenderer::staticMetaObject = { {
    QMetaObject::SuperData::link<QGraphicsObject::staticMetaObject>(),
    qt_meta_stringdata_QtAV__GraphicsItemRenderer.data,
    qt_meta_data_QtAV__GraphicsItemRenderer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtAV::GraphicsItemRenderer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtAV::GraphicsItemRenderer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtAV__GraphicsItemRenderer.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QPainterRenderer"))
        return static_cast< QPainterRenderer*>(this);
    return QGraphicsObject::qt_metacast(_clname);
}

int QtAV::GraphicsItemRenderer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtAV::GraphicsItemRenderer::sourceAspectRatioChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QtAV::GraphicsItemRenderer::regionOfInterestChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QtAV::GraphicsItemRenderer::outAspectRatioChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QtAV::GraphicsItemRenderer::outAspectRatioModeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QtAV::GraphicsItemRenderer::brightnessChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QtAV::GraphicsItemRenderer::contrastChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QtAV::GraphicsItemRenderer::hueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QtAV::GraphicsItemRenderer::saturationChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QtAV::GraphicsItemRenderer::backgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QtAV::GraphicsItemRenderer::orientationChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QtAV::GraphicsItemRenderer::videoRectChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QtAV::GraphicsItemRenderer::videoFrameSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QtAV::GraphicsItemRenderer::openGLChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
