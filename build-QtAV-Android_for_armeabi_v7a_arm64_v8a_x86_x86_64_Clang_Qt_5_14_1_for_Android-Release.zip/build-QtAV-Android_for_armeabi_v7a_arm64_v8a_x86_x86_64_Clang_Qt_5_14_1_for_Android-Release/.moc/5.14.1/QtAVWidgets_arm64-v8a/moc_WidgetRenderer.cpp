/****************************************************************************
** Meta object code from reading C++ file 'WidgetRenderer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/widgets/QtAVWidgets/WidgetRenderer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'WidgetRenderer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtAV__WidgetRenderer_t {
    QByteArrayData data[25];
    char stringdata0[421];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtAV__WidgetRenderer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtAV__WidgetRenderer_t qt_meta_stringdata_QtAV__WidgetRenderer = {
    {
QT_MOC_LITERAL(0, 0, 20), // "QtAV::WidgetRenderer"
QT_MOC_LITERAL(1, 21, 24), // "sourceAspectRatioChanged"
QT_MOC_LITERAL(2, 46, 0), // ""
QT_MOC_LITERAL(3, 47, 5), // "value"
QT_MOC_LITERAL(4, 53, 23), // "regionOfInterestChanged"
QT_MOC_LITERAL(5, 77, 21), // "outAspectRatioChanged"
QT_MOC_LITERAL(6, 99, 25), // "outAspectRatioModeChanged"
QT_MOC_LITERAL(7, 125, 17), // "brightnessChanged"
QT_MOC_LITERAL(8, 143, 15), // "contrastChanged"
QT_MOC_LITERAL(9, 159, 10), // "hueChanged"
QT_MOC_LITERAL(10, 170, 17), // "saturationChanged"
QT_MOC_LITERAL(11, 188, 22), // "backgroundColorChanged"
QT_MOC_LITERAL(12, 211, 18), // "orientationChanged"
QT_MOC_LITERAL(13, 230, 16), // "videoRectChanged"
QT_MOC_LITERAL(14, 247, 21), // "videoFrameSizeChanged"
QT_MOC_LITERAL(15, 269, 10), // "imageReady"
QT_MOC_LITERAL(16, 280, 15), // "backgroundColor"
QT_MOC_LITERAL(17, 296, 16), // "regionOfInterest"
QT_MOC_LITERAL(18, 313, 17), // "sourceAspectRatio"
QT_MOC_LITERAL(19, 331, 14), // "outAspectRatio"
QT_MOC_LITERAL(20, 346, 18), // "outAspectRatioMode"
QT_MOC_LITERAL(21, 365, 18), // "OutAspectRatioMode"
QT_MOC_LITERAL(22, 384, 11), // "orientation"
QT_MOC_LITERAL(23, 396, 9), // "videoRect"
QT_MOC_LITERAL(24, 406, 14) // "videoFrameSize"

    },
    "QtAV::WidgetRenderer\0sourceAspectRatioChanged\0"
    "\0value\0regionOfInterestChanged\0"
    "outAspectRatioChanged\0outAspectRatioModeChanged\0"
    "brightnessChanged\0contrastChanged\0"
    "hueChanged\0saturationChanged\0"
    "backgroundColorChanged\0orientationChanged\0"
    "videoRectChanged\0videoFrameSizeChanged\0"
    "imageReady\0backgroundColor\0regionOfInterest\0"
    "sourceAspectRatio\0outAspectRatio\0"
    "outAspectRatioMode\0OutAspectRatioMode\0"
    "orientation\0videoRect\0videoFrameSize"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtAV__WidgetRenderer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       8,  102, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   79,    2, 0x06 /* Public */,
       4,    0,   82,    2, 0x06 /* Public */,
       5,    0,   83,    2, 0x06 /* Public */,
       6,    0,   84,    2, 0x06 /* Public */,
       7,    1,   85,    2, 0x06 /* Public */,
       8,    1,   88,    2, 0x06 /* Public */,
       9,    1,   91,    2, 0x06 /* Public */,
      10,    1,   94,    2, 0x06 /* Public */,
      11,    0,   97,    2, 0x06 /* Public */,
      12,    0,   98,    2, 0x06 /* Public */,
      13,    0,   99,    2, 0x06 /* Public */,
      14,    0,  100,    2, 0x06 /* Public */,
      15,    0,  101,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      16, QMetaType::QColor, 0x00495103,
      17, QMetaType::QRectF, 0x00495103,
      18, QMetaType::QReal, 0x00495001,
      19, QMetaType::QReal, 0x00495103,
      20, 0x80000000 | 21, 0x0049510b,
      22, QMetaType::Int, 0x00495103,
      23, QMetaType::QRect, 0x00495001,
      24, QMetaType::QSize, 0x00495001,

 // properties: notify_signal_id
       8,
       1,
       0,
       2,
       3,
       9,
      10,
      11,

 // enums: name, alias, flags, count, data

 // enum data: key, value

       0        // eod
};

void QtAV::WidgetRenderer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<WidgetRenderer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sourceAspectRatioChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 1: _t->regionOfInterestChanged(); break;
        case 2: _t->outAspectRatioChanged(); break;
        case 3: _t->outAspectRatioModeChanged(); break;
        case 4: _t->brightnessChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 5: _t->contrastChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 6: _t->hueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 7: _t->saturationChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 8: _t->backgroundColorChanged(); break;
        case 9: _t->orientationChanged(); break;
        case 10: _t->videoRectChanged(); break;
        case 11: _t->videoFrameSizeChanged(); break;
        case 12: _t->imageReady(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (WidgetRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::sourceAspectRatioChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::regionOfInterestChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::outAspectRatioChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::outAspectRatioModeChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::brightnessChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::contrastChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::hueChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::saturationChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::backgroundColorChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::orientationChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::videoRectChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::videoFrameSizeChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (WidgetRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&WidgetRenderer::imageReady)) {
                *result = 12;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<WidgetRenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->backgroundColor(); break;
        case 1: *reinterpret_cast< QRectF*>(_v) = _t->regionOfInterest(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->sourceAspectRatio(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->outAspectRatio(); break;
        case 4: *reinterpret_cast< OutAspectRatioMode*>(_v) = _t->outAspectRatioMode(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->orientation(); break;
        case 6: *reinterpret_cast< QRect*>(_v) = _t->videoRect(); break;
        case 7: *reinterpret_cast< QSize*>(_v) = _t->videoFrameSize(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<WidgetRenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setRegionOfInterest(*reinterpret_cast< QRectF*>(_v)); break;
        case 3: _t->setOutAspectRatio(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setOutAspectRatioMode(*reinterpret_cast< OutAspectRatioMode*>(_v)); break;
        case 5: _t->setOrientation(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtAV::WidgetRenderer::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_QtAV__WidgetRenderer.data,
    qt_meta_data_QtAV__WidgetRenderer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtAV::WidgetRenderer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtAV::WidgetRenderer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtAV__WidgetRenderer.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QPainterRenderer"))
        return static_cast< QPainterRenderer*>(this);
    return QWidget::qt_metacast(_clname);
}

int QtAV::WidgetRenderer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtAV::WidgetRenderer::sourceAspectRatioChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QtAV::WidgetRenderer::regionOfInterestChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QtAV::WidgetRenderer::outAspectRatioChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QtAV::WidgetRenderer::outAspectRatioModeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QtAV::WidgetRenderer::brightnessChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QtAV::WidgetRenderer::contrastChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QtAV::WidgetRenderer::hueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QtAV::WidgetRenderer::saturationChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QtAV::WidgetRenderer::backgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QtAV::WidgetRenderer::orientationChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QtAV::WidgetRenderer::videoRectChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QtAV::WidgetRenderer::videoFrameSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QtAV::WidgetRenderer::imageReady()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
