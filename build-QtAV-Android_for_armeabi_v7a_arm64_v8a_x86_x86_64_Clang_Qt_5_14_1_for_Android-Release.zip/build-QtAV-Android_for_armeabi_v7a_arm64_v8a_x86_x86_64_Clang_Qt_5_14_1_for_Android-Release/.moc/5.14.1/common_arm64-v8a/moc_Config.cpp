/****************************************************************************
** Meta object code from reading C++ file 'Config.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/examples/common/Config.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Config.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Config_t {
    QByteArrayData data[98];
    char stringdata0[1507];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Config_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Config_t qt_meta_stringdata_Config = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Config"
QT_MOC_LITERAL(1, 7, 7), // "changed"
QT_MOC_LITERAL(2, 15, 0), // ""
QT_MOC_LITERAL(3, 16, 24), // "userShaderEnabledChanged"
QT_MOC_LITERAL(4, 41, 22), // "intermediateFBOChanged"
QT_MOC_LITERAL(5, 64, 17), // "fragHeaderChanged"
QT_MOC_LITERAL(6, 82, 17), // "fragSampleChanged"
QT_MOC_LITERAL(7, 100, 22), // "fragPostProcessChanged"
QT_MOC_LITERAL(8, 123, 15), // "lastFileChanged"
QT_MOC_LITERAL(9, 139, 21), // "forceFrameRateChanged"
QT_MOC_LITERAL(10, 161, 22), // "decodingThreadsChanged"
QT_MOC_LITERAL(11, 184, 1), // "n"
QT_MOC_LITERAL(12, 186, 27), // "decoderPriorityNamesChanged"
QT_MOC_LITERAL(13, 214, 25), // "registeredDecodersChanged"
QT_MOC_LITERAL(14, 240, 12), // "QVector<int>"
QT_MOC_LITERAL(15, 253, 1), // "r"
QT_MOC_LITERAL(16, 255, 15), // "zeroCopyChanged"
QT_MOC_LITERAL(17, 271, 17), // "captureDirChanged"
QT_MOC_LITERAL(18, 289, 3), // "dir"
QT_MOC_LITERAL(19, 293, 20), // "captureFormatChanged"
QT_MOC_LITERAL(20, 314, 3), // "fmt"
QT_MOC_LITERAL(21, 318, 21), // "captureQualityChanged"
QT_MOC_LITERAL(22, 340, 7), // "quality"
QT_MOC_LITERAL(23, 348, 20), // "avfilterVideoChanged"
QT_MOC_LITERAL(24, 369, 20), // "avfilterAudioChanged"
QT_MOC_LITERAL(25, 390, 22), // "subtitleEnabledChanged"
QT_MOC_LITERAL(26, 413, 23), // "subtitleAutoLoadChanged"
QT_MOC_LITERAL(27, 437, 22), // "subtitleEnginesChanged"
QT_MOC_LITERAL(28, 460, 19), // "subtitleFontChanged"
QT_MOC_LITERAL(29, 480, 20), // "subtitleColorChanged"
QT_MOC_LITERAL(30, 501, 22), // "subtitleOutlineChanged"
QT_MOC_LITERAL(31, 524, 27), // "subtitleOutlineColorChanged"
QT_MOC_LITERAL(32, 552, 27), // "subtitleBottomMarginChanged"
QT_MOC_LITERAL(33, 580, 20), // "subtitleDelayChanged"
QT_MOC_LITERAL(34, 601, 18), // "assFontFileChanged"
QT_MOC_LITERAL(35, 620, 18), // "assFontsDirChanged"
QT_MOC_LITERAL(36, 639, 24), // "assFontFileForcedChanged"
QT_MOC_LITERAL(37, 664, 21), // "previewEnabledChanged"
QT_MOC_LITERAL(38, 686, 19), // "previewWidthChanged"
QT_MOC_LITERAL(39, 706, 20), // "previewHeightChanged"
QT_MOC_LITERAL(40, 727, 10), // "EGLChanged"
QT_MOC_LITERAL(41, 738, 17), // "openGLTypeChanged"
QT_MOC_LITERAL(42, 756, 20), // "ANGLEPlatformChanged"
QT_MOC_LITERAL(43, 777, 29), // "avformatOptionsEnabledChanged"
QT_MOC_LITERAL(44, 807, 18), // "bufferValueChanged"
QT_MOC_LITERAL(45, 826, 14), // "timeoutChanged"
QT_MOC_LITERAL(46, 841, 21), // "abortOnTimeoutChanged"
QT_MOC_LITERAL(47, 863, 15), // "logLevelChanged"
QT_MOC_LITERAL(48, 879, 15), // "languageChanged"
QT_MOC_LITERAL(49, 895, 14), // "historyChanged"
QT_MOC_LITERAL(50, 910, 4), // "save"
QT_MOC_LITERAL(51, 915, 5), // "reset"
QT_MOC_LITERAL(52, 921, 10), // "addHistory"
QT_MOC_LITERAL(53, 932, 5), // "value"
QT_MOC_LITERAL(54, 938, 13), // "removeHistory"
QT_MOC_LITERAL(55, 952, 3), // "url"
QT_MOC_LITERAL(56, 956, 12), // "clearHistory"
QT_MOC_LITERAL(57, 969, 7), // "history"
QT_MOC_LITERAL(58, 977, 8), // "lastFile"
QT_MOC_LITERAL(59, 986, 14), // "forceFrameRate"
QT_MOC_LITERAL(60, 1001, 20), // "decoderPriorityNames"
QT_MOC_LITERAL(61, 1022, 8), // "zeroCopy"
QT_MOC_LITERAL(62, 1031, 10), // "captureDir"
QT_MOC_LITERAL(63, 1042, 13), // "captureFormat"
QT_MOC_LITERAL(64, 1056, 14), // "captureQuality"
QT_MOC_LITERAL(65, 1071, 15), // "subtitleEngines"
QT_MOC_LITERAL(66, 1087, 16), // "subtitleAutoLoad"
QT_MOC_LITERAL(67, 1104, 15), // "subtitleEnabled"
QT_MOC_LITERAL(68, 1120, 12), // "subtitleFont"
QT_MOC_LITERAL(69, 1133, 13), // "subtitleColor"
QT_MOC_LITERAL(70, 1147, 20), // "subtitleOutlineColor"
QT_MOC_LITERAL(71, 1168, 15), // "subtitleOutline"
QT_MOC_LITERAL(72, 1184, 20), // "subtitleBottomMargin"
QT_MOC_LITERAL(73, 1205, 13), // "subtitleDelay"
QT_MOC_LITERAL(74, 1219, 11), // "assFontFile"
QT_MOC_LITERAL(75, 1231, 11), // "assFontsDir"
QT_MOC_LITERAL(76, 1243, 17), // "assFontFileForced"
QT_MOC_LITERAL(77, 1261, 14), // "previewEnabled"
QT_MOC_LITERAL(78, 1276, 12), // "previewWidth"
QT_MOC_LITERAL(79, 1289, 13), // "previewHeight"
QT_MOC_LITERAL(80, 1303, 3), // "EGL"
QT_MOC_LITERAL(81, 1307, 10), // "openGLType"
QT_MOC_LITERAL(82, 1318, 10), // "OpenGLType"
QT_MOC_LITERAL(83, 1329, 13), // "ANGLEPlatform"
QT_MOC_LITERAL(84, 1343, 22), // "avformatOptionsEnabled"
QT_MOC_LITERAL(85, 1366, 7), // "timeout"
QT_MOC_LITERAL(86, 1374, 11), // "bufferValue"
QT_MOC_LITERAL(87, 1386, 8), // "logLevel"
QT_MOC_LITERAL(88, 1395, 8), // "language"
QT_MOC_LITERAL(89, 1404, 17), // "userShaderEnabled"
QT_MOC_LITERAL(90, 1422, 15), // "intermediateFBO"
QT_MOC_LITERAL(91, 1438, 10), // "fragHeader"
QT_MOC_LITERAL(92, 1449, 10), // "fragSample"
QT_MOC_LITERAL(93, 1460, 15), // "fragPostProcess"
QT_MOC_LITERAL(94, 1476, 4), // "Auto"
QT_MOC_LITERAL(95, 1481, 7), // "Desktop"
QT_MOC_LITERAL(96, 1489, 8), // "OpenGLES"
QT_MOC_LITERAL(97, 1498, 8) // "Software"

    },
    "Config\0changed\0\0userShaderEnabledChanged\0"
    "intermediateFBOChanged\0fragHeaderChanged\0"
    "fragSampleChanged\0fragPostProcessChanged\0"
    "lastFileChanged\0forceFrameRateChanged\0"
    "decodingThreadsChanged\0n\0"
    "decoderPriorityNamesChanged\0"
    "registeredDecodersChanged\0QVector<int>\0"
    "r\0zeroCopyChanged\0captureDirChanged\0"
    "dir\0captureFormatChanged\0fmt\0"
    "captureQualityChanged\0quality\0"
    "avfilterVideoChanged\0avfilterAudioChanged\0"
    "subtitleEnabledChanged\0subtitleAutoLoadChanged\0"
    "subtitleEnginesChanged\0subtitleFontChanged\0"
    "subtitleColorChanged\0subtitleOutlineChanged\0"
    "subtitleOutlineColorChanged\0"
    "subtitleBottomMarginChanged\0"
    "subtitleDelayChanged\0assFontFileChanged\0"
    "assFontsDirChanged\0assFontFileForcedChanged\0"
    "previewEnabledChanged\0previewWidthChanged\0"
    "previewHeightChanged\0EGLChanged\0"
    "openGLTypeChanged\0ANGLEPlatformChanged\0"
    "avformatOptionsEnabledChanged\0"
    "bufferValueChanged\0timeoutChanged\0"
    "abortOnTimeoutChanged\0logLevelChanged\0"
    "languageChanged\0historyChanged\0save\0"
    "reset\0addHistory\0value\0removeHistory\0"
    "url\0clearHistory\0history\0lastFile\0"
    "forceFrameRate\0decoderPriorityNames\0"
    "zeroCopy\0captureDir\0captureFormat\0"
    "captureQuality\0subtitleEngines\0"
    "subtitleAutoLoad\0subtitleEnabled\0"
    "subtitleFont\0subtitleColor\0"
    "subtitleOutlineColor\0subtitleOutline\0"
    "subtitleBottomMargin\0subtitleDelay\0"
    "assFontFile\0assFontsDir\0assFontFileForced\0"
    "previewEnabled\0previewWidth\0previewHeight\0"
    "EGL\0openGLType\0OpenGLType\0ANGLEPlatform\0"
    "avformatOptionsEnabled\0timeout\0"
    "bufferValue\0logLevel\0language\0"
    "userShaderEnabled\0intermediateFBO\0"
    "fragHeader\0fragSample\0fragPostProcess\0"
    "Auto\0Desktop\0OpenGLES\0Software"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Config[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      47,   14, // methods
      36,  310, // properties
       1,  454, // enums/sets
       0,    0, // constructors
       0,       // flags
      42,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  249,    2, 0x06 /* Public */,
       3,    0,  250,    2, 0x06 /* Public */,
       4,    0,  251,    2, 0x06 /* Public */,
       5,    0,  252,    2, 0x06 /* Public */,
       6,    0,  253,    2, 0x06 /* Public */,
       7,    0,  254,    2, 0x06 /* Public */,
       8,    0,  255,    2, 0x06 /* Public */,
       9,    0,  256,    2, 0x06 /* Public */,
      10,    1,  257,    2, 0x06 /* Public */,
      12,    0,  260,    2, 0x06 /* Public */,
      13,    1,  261,    2, 0x06 /* Public */,
      16,    0,  264,    2, 0x06 /* Public */,
      17,    1,  265,    2, 0x06 /* Public */,
      19,    1,  268,    2, 0x06 /* Public */,
      21,    1,  271,    2, 0x06 /* Public */,
      23,    0,  274,    2, 0x06 /* Public */,
      24,    0,  275,    2, 0x06 /* Public */,
      25,    0,  276,    2, 0x06 /* Public */,
      26,    0,  277,    2, 0x06 /* Public */,
      27,    0,  278,    2, 0x06 /* Public */,
      28,    0,  279,    2, 0x06 /* Public */,
      29,    0,  280,    2, 0x06 /* Public */,
      30,    0,  281,    2, 0x06 /* Public */,
      31,    0,  282,    2, 0x06 /* Public */,
      32,    0,  283,    2, 0x06 /* Public */,
      33,    0,  284,    2, 0x06 /* Public */,
      34,    0,  285,    2, 0x06 /* Public */,
      35,    0,  286,    2, 0x06 /* Public */,
      36,    0,  287,    2, 0x06 /* Public */,
      37,    0,  288,    2, 0x06 /* Public */,
      38,    0,  289,    2, 0x06 /* Public */,
      39,    0,  290,    2, 0x06 /* Public */,
      40,    0,  291,    2, 0x06 /* Public */,
      41,    0,  292,    2, 0x06 /* Public */,
      42,    0,  293,    2, 0x06 /* Public */,
      43,    0,  294,    2, 0x06 /* Public */,
      44,    0,  295,    2, 0x06 /* Public */,
      45,    0,  296,    2, 0x06 /* Public */,
      46,    0,  297,    2, 0x06 /* Public */,
      47,    0,  298,    2, 0x06 /* Public */,
      48,    0,  299,    2, 0x06 /* Public */,
      49,    0,  300,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      50,    0,  301,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
      51,    0,  302,    2, 0x02 /* Public */,
      52,    1,  303,    2, 0x02 /* Public */,
      54,    1,  306,    2, 0x02 /* Public */,
      56,    0,  309,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   11,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,

 // methods: parameters
    QMetaType::Bool,
    QMetaType::Void, QMetaType::QVariantMap,   53,
    QMetaType::Void, QMetaType::QString,   55,
    QMetaType::Void,

 // properties: name, type, flags
      57, QMetaType::QVariantList, 0x00495001,
      58, QMetaType::QString, 0x00495103,
      59, QMetaType::QReal, 0x00495103,
      60, QMetaType::QStringList, 0x00495103,
      61, QMetaType::Bool, 0x00495103,
      62, QMetaType::QString, 0x00495103,
      63, QMetaType::QString, 0x00495103,
      64, QMetaType::Int, 0x00495103,
      65, QMetaType::QStringList, 0x00495103,
      66, QMetaType::Bool, 0x00495103,
      67, QMetaType::Bool, 0x00495103,
      68, QMetaType::QFont, 0x00495103,
      69, QMetaType::QColor, 0x00495103,
      70, QMetaType::QColor, 0x00495103,
      71, QMetaType::Bool, 0x00495103,
      72, QMetaType::Int, 0x00495103,
      73, QMetaType::QReal, 0x00495103,
      74, QMetaType::QString, 0x00495103,
      75, QMetaType::QString, 0x00495103,
      76, QMetaType::Bool, 0x00495103,
      77, QMetaType::Bool, 0x00495103,
      78, QMetaType::Int, 0x00495103,
      79, QMetaType::Int, 0x00495103,
      80, QMetaType::Bool, 0x00495103,
      81, 0x80000000 | 82, 0x0049510b,
      83, QMetaType::QString, 0x00495103,
      84, QMetaType::Bool, 0x00495103,
      85, QMetaType::QReal, 0x00495103,
      86, QMetaType::Int, 0x00495103,
      87, QMetaType::QString, 0x00495103,
      88, QMetaType::QString, 0x00495103,
      89, QMetaType::Bool, 0x00495103,
      90, QMetaType::Bool, 0x00495103,
      91, QMetaType::QString, 0x00495103,
      92, QMetaType::QString, 0x00495103,
      93, QMetaType::QString, 0x00495103,

 // properties: notify_signal_id
      41,
       6,
       7,
       9,
      11,
      12,
      13,
      14,
      19,
      18,
      17,
      20,
      21,
      23,
      22,
      24,
      25,
      26,
      27,
      28,
      29,
      30,
      31,
      32,
      33,
      34,
      35,
      37,
      36,
      39,
      40,
       1,
       2,
       3,
       4,
       5,

 // enums: name, alias, flags, count, data
      82,   82, 0x0,    4,  459,

 // enum data: key, value
      94, uint(Config::Auto),
      95, uint(Config::Desktop),
      96, uint(Config::OpenGLES),
      97, uint(Config::Software),

       0        // eod
};

void Config::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Config *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->changed(); break;
        case 1: _t->userShaderEnabledChanged(); break;
        case 2: _t->intermediateFBOChanged(); break;
        case 3: _t->fragHeaderChanged(); break;
        case 4: _t->fragSampleChanged(); break;
        case 5: _t->fragPostProcessChanged(); break;
        case 6: _t->lastFileChanged(); break;
        case 7: _t->forceFrameRateChanged(); break;
        case 8: _t->decodingThreadsChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->decoderPriorityNamesChanged(); break;
        case 10: _t->registeredDecodersChanged((*reinterpret_cast< const QVector<int>(*)>(_a[1]))); break;
        case 11: _t->zeroCopyChanged(); break;
        case 12: _t->captureDirChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->captureFormatChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->captureQualityChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->avfilterVideoChanged(); break;
        case 16: _t->avfilterAudioChanged(); break;
        case 17: _t->subtitleEnabledChanged(); break;
        case 18: _t->subtitleAutoLoadChanged(); break;
        case 19: _t->subtitleEnginesChanged(); break;
        case 20: _t->subtitleFontChanged(); break;
        case 21: _t->subtitleColorChanged(); break;
        case 22: _t->subtitleOutlineChanged(); break;
        case 23: _t->subtitleOutlineColorChanged(); break;
        case 24: _t->subtitleBottomMarginChanged(); break;
        case 25: _t->subtitleDelayChanged(); break;
        case 26: _t->assFontFileChanged(); break;
        case 27: _t->assFontsDirChanged(); break;
        case 28: _t->assFontFileForcedChanged(); break;
        case 29: _t->previewEnabledChanged(); break;
        case 30: _t->previewWidthChanged(); break;
        case 31: _t->previewHeightChanged(); break;
        case 32: _t->EGLChanged(); break;
        case 33: _t->openGLTypeChanged(); break;
        case 34: _t->ANGLEPlatformChanged(); break;
        case 35: _t->avformatOptionsEnabledChanged(); break;
        case 36: _t->bufferValueChanged(); break;
        case 37: _t->timeoutChanged(); break;
        case 38: _t->abortOnTimeoutChanged(); break;
        case 39: _t->logLevelChanged(); break;
        case 40: _t->languageChanged(); break;
        case 41: _t->historyChanged(); break;
        case 42: _t->save(); break;
        case 43: { bool _r = _t->reset();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 44: _t->addHistory((*reinterpret_cast< const QVariantMap(*)>(_a[1]))); break;
        case 45: _t->removeHistory((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 46: _t->clearHistory(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<int> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::changed)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::userShaderEnabledChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::intermediateFBOChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::fragHeaderChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::fragSampleChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::fragPostProcessChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::lastFileChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::forceFrameRateChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (Config::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::decodingThreadsChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::decoderPriorityNamesChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (Config::*)(const QVector<int> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::registeredDecodersChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::zeroCopyChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (Config::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::captureDirChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (Config::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::captureFormatChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (Config::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::captureQualityChanged)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::avfilterVideoChanged)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::avfilterAudioChanged)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleEnabledChanged)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleAutoLoadChanged)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleEnginesChanged)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleFontChanged)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleColorChanged)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleOutlineChanged)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleOutlineColorChanged)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleBottomMarginChanged)) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::subtitleDelayChanged)) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::assFontFileChanged)) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::assFontsDirChanged)) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::assFontFileForcedChanged)) {
                *result = 28;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::previewEnabledChanged)) {
                *result = 29;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::previewWidthChanged)) {
                *result = 30;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::previewHeightChanged)) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::EGLChanged)) {
                *result = 32;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::openGLTypeChanged)) {
                *result = 33;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::ANGLEPlatformChanged)) {
                *result = 34;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::avformatOptionsEnabledChanged)) {
                *result = 35;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::bufferValueChanged)) {
                *result = 36;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::timeoutChanged)) {
                *result = 37;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::abortOnTimeoutChanged)) {
                *result = 38;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::logLevelChanged)) {
                *result = 39;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::languageChanged)) {
                *result = 40;
                return;
            }
        }
        {
            using _t = void (Config::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Config::historyChanged)) {
                *result = 41;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<Config *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QVariantList*>(_v) = _t->history(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->lastFile(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->forceFrameRate(); break;
        case 3: *reinterpret_cast< QStringList*>(_v) = _t->decoderPriorityNames(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->zeroCopy(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->captureDir(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->captureFormat(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->captureQuality(); break;
        case 8: *reinterpret_cast< QStringList*>(_v) = _t->subtitleEngines(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->subtitleAutoLoad(); break;
        case 10: *reinterpret_cast< bool*>(_v) = _t->subtitleEnabled(); break;
        case 11: *reinterpret_cast< QFont*>(_v) = _t->subtitleFont(); break;
        case 12: *reinterpret_cast< QColor*>(_v) = _t->subtitleColor(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->subtitleOutlineColor(); break;
        case 14: *reinterpret_cast< bool*>(_v) = _t->subtitleOutline(); break;
        case 15: *reinterpret_cast< int*>(_v) = _t->subtitleBottomMargin(); break;
        case 16: *reinterpret_cast< qreal*>(_v) = _t->subtitleDelay(); break;
        case 17: *reinterpret_cast< QString*>(_v) = _t->assFontFile(); break;
        case 18: *reinterpret_cast< QString*>(_v) = _t->assFontsDir(); break;
        case 19: *reinterpret_cast< bool*>(_v) = _t->isAssFontFileForced(); break;
        case 20: *reinterpret_cast< bool*>(_v) = _t->previewEnabled(); break;
        case 21: *reinterpret_cast< int*>(_v) = _t->previewWidth(); break;
        case 22: *reinterpret_cast< int*>(_v) = _t->previewHeight(); break;
        case 23: *reinterpret_cast< bool*>(_v) = _t->isEGL(); break;
        case 24: *reinterpret_cast< OpenGLType*>(_v) = _t->openGLType(); break;
        case 25: *reinterpret_cast< QString*>(_v) = _t->getANGLEPlatform(); break;
        case 26: *reinterpret_cast< bool*>(_v) = _t->avformatOptionsEnabled(); break;
        case 27: *reinterpret_cast< qreal*>(_v) = _t->timeout(); break;
        case 28: *reinterpret_cast< int*>(_v) = _t->bufferValue(); break;
        case 29: *reinterpret_cast< QString*>(_v) = _t->logLevel(); break;
        case 30: *reinterpret_cast< QString*>(_v) = _t->language(); break;
        case 31: *reinterpret_cast< bool*>(_v) = _t->userShaderEnabled(); break;
        case 32: *reinterpret_cast< bool*>(_v) = _t->intermediateFBO(); break;
        case 33: *reinterpret_cast< QString*>(_v) = _t->fragHeader(); break;
        case 34: *reinterpret_cast< QString*>(_v) = _t->fragSample(); break;
        case 35: *reinterpret_cast< QString*>(_v) = _t->fragPostProcess(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<Config *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 1: _t->setLastFile(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setForceFrameRate(*reinterpret_cast< qreal*>(_v)); break;
        case 3: _t->setDecoderPriorityNames(*reinterpret_cast< QStringList*>(_v)); break;
        case 4: _t->setZeroCopy(*reinterpret_cast< bool*>(_v)); break;
        case 5: _t->setCaptureDir(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setCaptureFormat(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setCaptureQuality(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setSubtitleEngines(*reinterpret_cast< QStringList*>(_v)); break;
        case 9: _t->setSubtitleAutoLoad(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setSubtitleEnabled(*reinterpret_cast< bool*>(_v)); break;
        case 11: _t->setSubtitleFont(*reinterpret_cast< QFont*>(_v)); break;
        case 12: _t->setSubtitleColor(*reinterpret_cast< QColor*>(_v)); break;
        case 13: _t->setSubtitleOutlineColor(*reinterpret_cast< QColor*>(_v)); break;
        case 14: _t->setSubtitleOutline(*reinterpret_cast< bool*>(_v)); break;
        case 15: _t->setSubtitleBottomMargin(*reinterpret_cast< int*>(_v)); break;
        case 16: _t->setSubtitleDelay(*reinterpret_cast< qreal*>(_v)); break;
        case 17: _t->setAssFontFile(*reinterpret_cast< QString*>(_v)); break;
        case 18: _t->setAssFontsDir(*reinterpret_cast< QString*>(_v)); break;
        case 19: _t->setAssFontFileForced(*reinterpret_cast< bool*>(_v)); break;
        case 20: _t->setPreviewEnabled(*reinterpret_cast< bool*>(_v)); break;
        case 21: _t->setPreviewWidth(*reinterpret_cast< int*>(_v)); break;
        case 22: _t->setPreviewHeight(*reinterpret_cast< int*>(_v)); break;
        case 23: _t->setEGL(*reinterpret_cast< bool*>(_v)); break;
        case 24: _t->setOpenGLType(*reinterpret_cast< OpenGLType*>(_v)); break;
        case 25: _t->setANGLEPlatform(*reinterpret_cast< QString*>(_v)); break;
        case 26: _t->setAvformatOptionsEnabled(*reinterpret_cast< bool*>(_v)); break;
        case 27: _t->setTimeout(*reinterpret_cast< qreal*>(_v)); break;
        case 28: _t->setBufferValue(*reinterpret_cast< int*>(_v)); break;
        case 29: _t->setLogLevel(*reinterpret_cast< QString*>(_v)); break;
        case 30: _t->setLanguage(*reinterpret_cast< QString*>(_v)); break;
        case 31: _t->setUserShaderEnabled(*reinterpret_cast< bool*>(_v)); break;
        case 32: _t->setIntermediateFBO(*reinterpret_cast< bool*>(_v)); break;
        case 33: _t->setFragHeader(*reinterpret_cast< QString*>(_v)); break;
        case 34: _t->setFragSample(*reinterpret_cast< QString*>(_v)); break;
        case 35: _t->setFragPostProcess(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject Config::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_Config.data,
    qt_meta_data_Config,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Config::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Config::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Config.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Config::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 36;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 36;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 36;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 36;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 36;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Config::changed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Config::userShaderEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void Config::intermediateFBOChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Config::fragHeaderChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void Config::fragSampleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void Config::fragPostProcessChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void Config::lastFileChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void Config::forceFrameRateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void Config::decodingThreadsChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Config::decoderPriorityNamesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void Config::registeredDecodersChanged(const QVector<int> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void Config::zeroCopyChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void Config::captureDirChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void Config::captureFormatChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void Config::captureQualityChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void Config::avfilterVideoChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void Config::avfilterAudioChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}

// SIGNAL 17
void Config::subtitleEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void Config::subtitleAutoLoadChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}

// SIGNAL 19
void Config::subtitleEnginesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 19, nullptr);
}

// SIGNAL 20
void Config::subtitleFontChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 20, nullptr);
}

// SIGNAL 21
void Config::subtitleColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 21, nullptr);
}

// SIGNAL 22
void Config::subtitleOutlineChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 22, nullptr);
}

// SIGNAL 23
void Config::subtitleOutlineColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 23, nullptr);
}

// SIGNAL 24
void Config::subtitleBottomMarginChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 24, nullptr);
}

// SIGNAL 25
void Config::subtitleDelayChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 25, nullptr);
}

// SIGNAL 26
void Config::assFontFileChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 26, nullptr);
}

// SIGNAL 27
void Config::assFontsDirChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 27, nullptr);
}

// SIGNAL 28
void Config::assFontFileForcedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 28, nullptr);
}

// SIGNAL 29
void Config::previewEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 29, nullptr);
}

// SIGNAL 30
void Config::previewWidthChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 30, nullptr);
}

// SIGNAL 31
void Config::previewHeightChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 31, nullptr);
}

// SIGNAL 32
void Config::EGLChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 32, nullptr);
}

// SIGNAL 33
void Config::openGLTypeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 33, nullptr);
}

// SIGNAL 34
void Config::ANGLEPlatformChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 34, nullptr);
}

// SIGNAL 35
void Config::avformatOptionsEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 35, nullptr);
}

// SIGNAL 36
void Config::bufferValueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 36, nullptr);
}

// SIGNAL 37
void Config::timeoutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 37, nullptr);
}

// SIGNAL 38
void Config::abortOnTimeoutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 38, nullptr);
}

// SIGNAL 39
void Config::logLevelChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 39, nullptr);
}

// SIGNAL 40
void Config::languageChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 40, nullptr);
}

// SIGNAL 41
void Config::historyChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 41, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
