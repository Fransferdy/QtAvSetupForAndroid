/****************************************************************************
** Meta object code from reading C++ file 'SubtitleFilter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/src/QtAV/SubtitleFilter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SubtitleFilter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtAV__SubtitleFilter_t {
    QByteArrayData data[41];
    char stringdata0[472];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtAV__SubtitleFilter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtAV__SubtitleFilter_t qt_meta_stringdata_QtAV__SubtitleFilter = {
    {
QT_MOC_LITERAL(0, 0, 20), // "QtAV::SubtitleFilter"
QT_MOC_LITERAL(1, 21, 11), // "rectChanged"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 11), // "fontChanged"
QT_MOC_LITERAL(4, 46, 12), // "colorChanged"
QT_MOC_LITERAL(5, 59, 15), // "autoLoadChanged"
QT_MOC_LITERAL(6, 75, 5), // "value"
QT_MOC_LITERAL(7, 81, 11), // "fileChanged"
QT_MOC_LITERAL(8, 93, 16), // "canRenderChanged"
QT_MOC_LITERAL(9, 110, 6), // "loaded"
QT_MOC_LITERAL(10, 117, 4), // "path"
QT_MOC_LITERAL(11, 122, 12), // "codecChanged"
QT_MOC_LITERAL(12, 135, 14), // "enginesChanged"
QT_MOC_LITERAL(13, 150, 17), // "fuzzyMatchChanged"
QT_MOC_LITERAL(14, 168, 14), // "contentChanged"
QT_MOC_LITERAL(15, 183, 11), // "dirsChanged"
QT_MOC_LITERAL(16, 195, 15), // "suffixesChanged"
QT_MOC_LITERAL(17, 211, 24), // "supportedSuffixesChanged"
QT_MOC_LITERAL(18, 236, 13), // "engineChanged"
QT_MOC_LITERAL(19, 250, 12), // "delayChanged"
QT_MOC_LITERAL(20, 263, 15), // "fontFileChanged"
QT_MOC_LITERAL(21, 279, 15), // "fontsDirChanged"
QT_MOC_LITERAL(22, 295, 21), // "fontFileForcedChanged"
QT_MOC_LITERAL(23, 317, 11), // "setAutoLoad"
QT_MOC_LITERAL(24, 329, 5), // "codec"
QT_MOC_LITERAL(25, 335, 7), // "engines"
QT_MOC_LITERAL(26, 343, 6), // "engine"
QT_MOC_LITERAL(27, 350, 10), // "fuzzyMatch"
QT_MOC_LITERAL(28, 361, 4), // "dirs"
QT_MOC_LITERAL(29, 366, 8), // "suffixes"
QT_MOC_LITERAL(30, 375, 17), // "supportedSuffixes"
QT_MOC_LITERAL(31, 393, 9), // "canRender"
QT_MOC_LITERAL(32, 403, 5), // "delay"
QT_MOC_LITERAL(33, 409, 8), // "autoLoad"
QT_MOC_LITERAL(34, 418, 4), // "file"
QT_MOC_LITERAL(35, 423, 4), // "rect"
QT_MOC_LITERAL(36, 428, 4), // "font"
QT_MOC_LITERAL(37, 433, 5), // "color"
QT_MOC_LITERAL(38, 439, 8), // "fontFile"
QT_MOC_LITERAL(39, 448, 8), // "fontsDir"
QT_MOC_LITERAL(40, 457, 14) // "fontFileForced"

    },
    "QtAV::SubtitleFilter\0rectChanged\0\0"
    "fontChanged\0colorChanged\0autoLoadChanged\0"
    "value\0fileChanged\0canRenderChanged\0"
    "loaded\0path\0codecChanged\0enginesChanged\0"
    "fuzzyMatchChanged\0contentChanged\0"
    "dirsChanged\0suffixesChanged\0"
    "supportedSuffixesChanged\0engineChanged\0"
    "delayChanged\0fontFileChanged\0"
    "fontsDirChanged\0fontFileForcedChanged\0"
    "setAutoLoad\0codec\0engines\0engine\0"
    "fuzzyMatch\0dirs\0suffixes\0supportedSuffixes\0"
    "canRender\0delay\0autoLoad\0file\0rect\0"
    "font\0color\0fontFile\0fontsDir\0"
    "fontFileForced"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtAV__SubtitleFilter[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
      17,  140, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      19,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x06 /* Public */,
       3,    0,  115,    2, 0x06 /* Public */,
       4,    0,  116,    2, 0x06 /* Public */,
       5,    1,  117,    2, 0x06 /* Public */,
       7,    0,  120,    2, 0x06 /* Public */,
       8,    0,  121,    2, 0x06 /* Public */,
       9,    1,  122,    2, 0x06 /* Public */,
      11,    0,  125,    2, 0x06 /* Public */,
      12,    0,  126,    2, 0x06 /* Public */,
      13,    0,  127,    2, 0x06 /* Public */,
      14,    0,  128,    2, 0x06 /* Public */,
      15,    0,  129,    2, 0x06 /* Public */,
      16,    0,  130,    2, 0x06 /* Public */,
      17,    0,  131,    2, 0x06 /* Public */,
      18,    0,  132,    2, 0x06 /* Public */,
      19,    0,  133,    2, 0x06 /* Public */,
      20,    0,  134,    2, 0x06 /* Public */,
      21,    0,  135,    2, 0x06 /* Public */,
      22,    0,  136,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      23,    1,  137,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    6,

 // properties: name, type, flags
      24, QMetaType::QByteArray, 0x00495103,
      25, QMetaType::QStringList, 0x00495103,
      26, QMetaType::QString, 0x00495001,
      27, QMetaType::Bool, 0x00495103,
      28, QMetaType::QStringList, 0x00495103,
      29, QMetaType::QStringList, 0x00495103,
      30, QMetaType::QStringList, 0x00495001,
      31, QMetaType::Bool, 0x00495001,
      32, QMetaType::QReal, 0x00495103,
      33, QMetaType::Bool, 0x00495103,
      34, QMetaType::QString, 0x00495103,
      35, QMetaType::QRectF, 0x00495103,
      36, QMetaType::QFont, 0x00495103,
      37, QMetaType::QColor, 0x00495103,
      38, QMetaType::QString, 0x00495103,
      39, QMetaType::QString, 0x00495103,
      40, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       7,
       8,
      14,
       9,
      11,
      12,
      13,
       5,
      15,
       3,
       4,
       0,
       1,
       2,
      16,
      17,
      18,

       0        // eod
};

void QtAV::SubtitleFilter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SubtitleFilter *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->rectChanged(); break;
        case 1: _t->fontChanged(); break;
        case 2: _t->colorChanged(); break;
        case 3: _t->autoLoadChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->fileChanged(); break;
        case 5: _t->canRenderChanged(); break;
        case 6: _t->loaded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->codecChanged(); break;
        case 8: _t->enginesChanged(); break;
        case 9: _t->fuzzyMatchChanged(); break;
        case 10: _t->contentChanged(); break;
        case 11: _t->dirsChanged(); break;
        case 12: _t->suffixesChanged(); break;
        case 13: _t->supportedSuffixesChanged(); break;
        case 14: _t->engineChanged(); break;
        case 15: _t->delayChanged(); break;
        case 16: _t->fontFileChanged(); break;
        case 17: _t->fontsDirChanged(); break;
        case 18: _t->fontFileForcedChanged(); break;
        case 19: _t->setAutoLoad((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::rectChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::fontChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::colorChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::autoLoadChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::fileChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::canRenderChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::loaded)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::codecChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::enginesChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::fuzzyMatchChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::contentChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::dirsChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::suffixesChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::supportedSuffixesChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::engineChanged)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::delayChanged)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::fontFileChanged)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::fontsDirChanged)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (SubtitleFilter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SubtitleFilter::fontFileForcedChanged)) {
                *result = 18;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<SubtitleFilter *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QByteArray*>(_v) = _t->codec(); break;
        case 1: *reinterpret_cast< QStringList*>(_v) = _t->engines(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->engine(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->fuzzyMatch(); break;
        case 4: *reinterpret_cast< QStringList*>(_v) = _t->dirs(); break;
        case 5: *reinterpret_cast< QStringList*>(_v) = _t->suffixes(); break;
        case 6: *reinterpret_cast< QStringList*>(_v) = _t->supportedSuffixes(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->canRender(); break;
        case 8: *reinterpret_cast< qreal*>(_v) = _t->delay(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->autoLoad(); break;
        case 10: *reinterpret_cast< QString*>(_v) = _t->file(); break;
        case 11: *reinterpret_cast< QRectF*>(_v) = _t->rect(); break;
        case 12: *reinterpret_cast< QFont*>(_v) = _t->font(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->color(); break;
        case 14: *reinterpret_cast< QString*>(_v) = _t->fontFile(); break;
        case 15: *reinterpret_cast< QString*>(_v) = _t->fontsDir(); break;
        case 16: *reinterpret_cast< bool*>(_v) = _t->isFontFileForced(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<SubtitleFilter *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setCodec(*reinterpret_cast< QByteArray*>(_v)); break;
        case 1: _t->setEngines(*reinterpret_cast< QStringList*>(_v)); break;
        case 3: _t->setFuzzyMatch(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setDirs(*reinterpret_cast< QStringList*>(_v)); break;
        case 5: _t->setSuffixes(*reinterpret_cast< QStringList*>(_v)); break;
        case 8: _t->setDelay(*reinterpret_cast< qreal*>(_v)); break;
        case 9: _t->setAutoLoad(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setFile(*reinterpret_cast< QString*>(_v)); break;
        case 11: _t->setRect(*reinterpret_cast< QRectF*>(_v)); break;
        case 12: _t->setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 13: _t->setColor(*reinterpret_cast< QColor*>(_v)); break;
        case 14: _t->setFontFile(*reinterpret_cast< QString*>(_v)); break;
        case 15: _t->setFontsDir(*reinterpret_cast< QString*>(_v)); break;
        case 16: _t->setFontFileForced(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtAV::SubtitleFilter::staticMetaObject = { {
    QMetaObject::SuperData::link<VideoFilter::staticMetaObject>(),
    qt_meta_stringdata_QtAV__SubtitleFilter.data,
    qt_meta_data_QtAV__SubtitleFilter,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtAV::SubtitleFilter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtAV::SubtitleFilter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtAV__SubtitleFilter.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "SubtitleAPIProxy"))
        return static_cast< SubtitleAPIProxy*>(this);
    return VideoFilter::qt_metacast(_clname);
}

int QtAV::SubtitleFilter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = VideoFilter::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 17;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtAV::SubtitleFilter::rectChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QtAV::SubtitleFilter::fontChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QtAV::SubtitleFilter::colorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QtAV::SubtitleFilter::autoLoadChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QtAV::SubtitleFilter::fileChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QtAV::SubtitleFilter::canRenderChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QtAV::SubtitleFilter::loaded(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QtAV::SubtitleFilter::codecChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QtAV::SubtitleFilter::enginesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QtAV::SubtitleFilter::fuzzyMatchChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QtAV::SubtitleFilter::contentChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QtAV::SubtitleFilter::dirsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QtAV::SubtitleFilter::suffixesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void QtAV::SubtitleFilter::supportedSuffixesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void QtAV::SubtitleFilter::engineChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void QtAV::SubtitleFilter::delayChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void QtAV::SubtitleFilter::fontFileChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}

// SIGNAL 17
void QtAV::SubtitleFilter::fontsDirChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void QtAV::SubtitleFilter::fontFileForcedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
