/****************************************************************************
** Meta object code from reading C++ file 'Subtitle.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/src/QtAV/Subtitle.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Subtitle.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtAV__Subtitle_t {
    QByteArrayData data[39];
    char stringdata0[446];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtAV__Subtitle_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtAV__Subtitle_t qt_meta_stringdata_QtAV__Subtitle = {
    {
QT_MOC_LITERAL(0, 0, 14), // "QtAV::Subtitle"
QT_MOC_LITERAL(1, 15, 6), // "loaded"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 4), // "path"
QT_MOC_LITERAL(4, 28, 16), // "canRenderChanged"
QT_MOC_LITERAL(5, 45, 12), // "codecChanged"
QT_MOC_LITERAL(6, 58, 14), // "enginesChanged"
QT_MOC_LITERAL(7, 73, 17), // "fuzzyMatchChanged"
QT_MOC_LITERAL(8, 91, 14), // "contentChanged"
QT_MOC_LITERAL(9, 106, 14), // "rawDataChanged"
QT_MOC_LITERAL(10, 121, 15), // "fileNameChanged"
QT_MOC_LITERAL(11, 137, 11), // "dirsChanged"
QT_MOC_LITERAL(12, 149, 15), // "suffixesChanged"
QT_MOC_LITERAL(13, 165, 24), // "supportedSuffixesChanged"
QT_MOC_LITERAL(14, 190, 13), // "engineChanged"
QT_MOC_LITERAL(15, 204, 12), // "delayChanged"
QT_MOC_LITERAL(16, 217, 15), // "fontFileChanged"
QT_MOC_LITERAL(17, 233, 15), // "fontsDirChanged"
QT_MOC_LITERAL(18, 249, 21), // "fontFileForcedChanged"
QT_MOC_LITERAL(19, 271, 4), // "load"
QT_MOC_LITERAL(20, 276, 9), // "loadAsync"
QT_MOC_LITERAL(21, 286, 12), // "setTimestamp"
QT_MOC_LITERAL(22, 299, 1), // "t"
QT_MOC_LITERAL(23, 301, 5), // "codec"
QT_MOC_LITERAL(24, 307, 7), // "engines"
QT_MOC_LITERAL(25, 315, 6), // "engine"
QT_MOC_LITERAL(26, 322, 10), // "fuzzyMatch"
QT_MOC_LITERAL(27, 333, 7), // "rawData"
QT_MOC_LITERAL(28, 341, 8), // "fileName"
QT_MOC_LITERAL(29, 350, 4), // "dirs"
QT_MOC_LITERAL(30, 355, 8), // "suffixes"
QT_MOC_LITERAL(31, 364, 17), // "supportedSuffixes"
QT_MOC_LITERAL(32, 382, 9), // "timestamp"
QT_MOC_LITERAL(33, 392, 5), // "delay"
QT_MOC_LITERAL(34, 398, 4), // "text"
QT_MOC_LITERAL(35, 403, 9), // "canRender"
QT_MOC_LITERAL(36, 413, 8), // "fontFile"
QT_MOC_LITERAL(37, 422, 8), // "fontsDir"
QT_MOC_LITERAL(38, 431, 14) // "fontFileForced"

    },
    "QtAV::Subtitle\0loaded\0\0path\0"
    "canRenderChanged\0codecChanged\0"
    "enginesChanged\0fuzzyMatchChanged\0"
    "contentChanged\0rawDataChanged\0"
    "fileNameChanged\0dirsChanged\0suffixesChanged\0"
    "supportedSuffixesChanged\0engineChanged\0"
    "delayChanged\0fontFileChanged\0"
    "fontsDirChanged\0fontFileForcedChanged\0"
    "load\0loadAsync\0setTimestamp\0t\0codec\0"
    "engines\0engine\0fuzzyMatch\0rawData\0"
    "fileName\0dirs\0suffixes\0supportedSuffixes\0"
    "timestamp\0delay\0text\0canRender\0fontFile\0"
    "fontsDir\0fontFileForced"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtAV__Subtitle[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
      17,  138, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      17,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  114,    2, 0x06 /* Public */,
       1,    0,  117,    2, 0x26 /* Public | MethodCloned */,
       4,    0,  118,    2, 0x06 /* Public */,
       5,    0,  119,    2, 0x06 /* Public */,
       6,    0,  120,    2, 0x06 /* Public */,
       7,    0,  121,    2, 0x06 /* Public */,
       8,    0,  122,    2, 0x06 /* Public */,
       9,    0,  123,    2, 0x06 /* Public */,
      10,    0,  124,    2, 0x06 /* Public */,
      11,    0,  125,    2, 0x06 /* Public */,
      12,    0,  126,    2, 0x06 /* Public */,
      13,    0,  127,    2, 0x06 /* Public */,
      14,    0,  128,    2, 0x06 /* Public */,
      15,    0,  129,    2, 0x06 /* Public */,
      16,    0,  130,    2, 0x06 /* Public */,
      17,    0,  131,    2, 0x06 /* Public */,
      18,    0,  132,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      19,    0,  133,    2, 0x0a /* Public */,
      20,    0,  134,    2, 0x0a /* Public */,
      21,    1,  135,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,   22,

 // properties: name, type, flags
      23, QMetaType::QByteArray, 0x00495103,
      24, QMetaType::QStringList, 0x00495103,
      25, QMetaType::QString, 0x00495001,
      26, QMetaType::Bool, 0x00495103,
      27, QMetaType::QByteArray, 0x00495103,
      28, QMetaType::QString, 0x00495103,
      29, QMetaType::QStringList, 0x00495103,
      30, QMetaType::QStringList, 0x00495103,
      31, QMetaType::QStringList, 0x00495001,
      32, QMetaType::QReal, 0x00095103,
      33, QMetaType::QReal, 0x00495103,
      34, QMetaType::QString, 0x00095001,
       1, QMetaType::Bool, 0x00095001,
      35, QMetaType::Bool, 0x00495001,
      36, QMetaType::QString, 0x00495103,
      37, QMetaType::QString, 0x00495103,
      38, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       3,
       4,
      12,
       5,
       7,
       8,
       9,
      10,
      11,
       0,
      13,
       0,
       0,
       2,
      14,
      15,
      16,

       0        // eod
};

void QtAV::Subtitle::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Subtitle *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->loaded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->loaded(); break;
        case 2: _t->canRenderChanged(); break;
        case 3: _t->codecChanged(); break;
        case 4: _t->enginesChanged(); break;
        case 5: _t->fuzzyMatchChanged(); break;
        case 6: _t->contentChanged(); break;
        case 7: _t->rawDataChanged(); break;
        case 8: _t->fileNameChanged(); break;
        case 9: _t->dirsChanged(); break;
        case 10: _t->suffixesChanged(); break;
        case 11: _t->supportedSuffixesChanged(); break;
        case 12: _t->engineChanged(); break;
        case 13: _t->delayChanged(); break;
        case 14: _t->fontFileChanged(); break;
        case 15: _t->fontsDirChanged(); break;
        case 16: _t->fontFileForcedChanged(); break;
        case 17: _t->load(); break;
        case 18: _t->loadAsync(); break;
        case 19: _t->setTimestamp((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Subtitle::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::loaded)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::canRenderChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::codecChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::enginesChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::fuzzyMatchChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::contentChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::rawDataChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::fileNameChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::dirsChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::suffixesChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::supportedSuffixesChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::engineChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::delayChanged)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::fontFileChanged)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::fontsDirChanged)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (Subtitle::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Subtitle::fontFileForcedChanged)) {
                *result = 16;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<Subtitle *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QByteArray*>(_v) = _t->codec(); break;
        case 1: *reinterpret_cast< QStringList*>(_v) = _t->engines(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->engine(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->fuzzyMatch(); break;
        case 4: *reinterpret_cast< QByteArray*>(_v) = _t->rawData(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->fileName(); break;
        case 6: *reinterpret_cast< QStringList*>(_v) = _t->dirs(); break;
        case 7: *reinterpret_cast< QStringList*>(_v) = _t->suffixes(); break;
        case 8: *reinterpret_cast< QStringList*>(_v) = _t->supportedSuffixes(); break;
        case 9: *reinterpret_cast< qreal*>(_v) = _t->timestamp(); break;
        case 10: *reinterpret_cast< qreal*>(_v) = _t->delay(); break;
        case 11: *reinterpret_cast< QString*>(_v) = _t->getText(); break;
        case 12: *reinterpret_cast< bool*>(_v) = _t->isLoaded(); break;
        case 13: *reinterpret_cast< bool*>(_v) = _t->canRender(); break;
        case 14: *reinterpret_cast< QString*>(_v) = _t->fontFile(); break;
        case 15: *reinterpret_cast< QString*>(_v) = _t->fontsDir(); break;
        case 16: *reinterpret_cast< bool*>(_v) = _t->isFontFileForced(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<Subtitle *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setCodec(*reinterpret_cast< QByteArray*>(_v)); break;
        case 1: _t->setEngines(*reinterpret_cast< QStringList*>(_v)); break;
        case 3: _t->setFuzzyMatch(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setRawData(*reinterpret_cast< QByteArray*>(_v)); break;
        case 5: _t->setFileName(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setDirs(*reinterpret_cast< QStringList*>(_v)); break;
        case 7: _t->setSuffixes(*reinterpret_cast< QStringList*>(_v)); break;
        case 9: _t->setTimestamp(*reinterpret_cast< qreal*>(_v)); break;
        case 10: _t->setDelay(*reinterpret_cast< qreal*>(_v)); break;
        case 14: _t->setFontFile(*reinterpret_cast< QString*>(_v)); break;
        case 15: _t->setFontsDir(*reinterpret_cast< QString*>(_v)); break;
        case 16: _t->setFontFileForced(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtAV::Subtitle::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_QtAV__Subtitle.data,
    qt_meta_data_QtAV__Subtitle,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtAV::Subtitle::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtAV::Subtitle::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtAV__Subtitle.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int QtAV::Subtitle::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 17;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 17;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtAV::Subtitle::loaded(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 2
void QtAV::Subtitle::canRenderChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QtAV::Subtitle::codecChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QtAV::Subtitle::enginesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QtAV::Subtitle::fuzzyMatchChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QtAV::Subtitle::contentChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void QtAV::Subtitle::rawDataChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QtAV::Subtitle::fileNameChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QtAV::Subtitle::dirsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QtAV::Subtitle::suffixesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QtAV::Subtitle::supportedSuffixesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QtAV::Subtitle::engineChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void QtAV::Subtitle::delayChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void QtAV::Subtitle::fontFileChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void QtAV::Subtitle::fontsDirChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void QtAV::Subtitle::fontFileForcedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
