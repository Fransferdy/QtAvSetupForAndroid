/****************************************************************************
** Meta object code from reading C++ file 'QuickFBORenderer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/qml/QmlAV/QuickFBORenderer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QuickFBORenderer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtAV__QuickFBORenderer_t {
    QByteArrayData data[48];
    char stringdata0[742];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtAV__QuickFBORenderer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtAV__QuickFBORenderer_t qt_meta_stringdata_QtAV__QuickFBORenderer = {
    {
QT_MOC_LITERAL(0, 0, 22), // "QtAV::QuickFBORenderer"
QT_MOC_LITERAL(1, 23, 13), // "sourceChanged"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 15), // "fillModeChanged"
QT_MOC_LITERAL(4, 54, 26), // "QuickFBORenderer::FillMode"
QT_MOC_LITERAL(5, 81, 18), // "orientationChanged"
QT_MOC_LITERAL(6, 100, 18), // "contentRectChanged"
QT_MOC_LITERAL(7, 119, 23), // "regionOfInterestChanged"
QT_MOC_LITERAL(8, 143, 13), // "openGLChanged"
QT_MOC_LITERAL(9, 157, 24), // "sourceAspectRatioChanged"
QT_MOC_LITERAL(10, 182, 5), // "value"
QT_MOC_LITERAL(11, 188, 21), // "videoFrameSizeChanged"
QT_MOC_LITERAL(12, 210, 22), // "backgroundColorChanged"
QT_MOC_LITERAL(13, 233, 17), // "brightnessChanged"
QT_MOC_LITERAL(14, 251, 15), // "contrastChanged"
QT_MOC_LITERAL(15, 267, 10), // "hueChanged"
QT_MOC_LITERAL(16, 278, 17), // "saturationChanged"
QT_MOC_LITERAL(17, 296, 14), // "mapPointToItem"
QT_MOC_LITERAL(18, 311, 5), // "point"
QT_MOC_LITERAL(19, 317, 13), // "mapRectToItem"
QT_MOC_LITERAL(20, 331, 9), // "rectangle"
QT_MOC_LITERAL(21, 341, 24), // "mapNormalizedPointToItem"
QT_MOC_LITERAL(22, 366, 23), // "mapNormalizedRectToItem"
QT_MOC_LITERAL(23, 390, 16), // "mapPointToSource"
QT_MOC_LITERAL(24, 407, 15), // "mapRectToSource"
QT_MOC_LITERAL(25, 423, 26), // "mapPointToSourceNormalized"
QT_MOC_LITERAL(26, 450, 25), // "mapRectToSourceNormalized"
QT_MOC_LITERAL(27, 476, 6), // "opengl"
QT_MOC_LITERAL(28, 483, 6), // "source"
QT_MOC_LITERAL(29, 490, 8), // "fillMode"
QT_MOC_LITERAL(30, 499, 8), // "FillMode"
QT_MOC_LITERAL(31, 508, 11), // "orientation"
QT_MOC_LITERAL(32, 520, 11), // "contentRect"
QT_MOC_LITERAL(33, 532, 10), // "sourceRect"
QT_MOC_LITERAL(34, 543, 16), // "regionOfInterest"
QT_MOC_LITERAL(35, 560, 17), // "sourceAspectRatio"
QT_MOC_LITERAL(36, 578, 14), // "videoFrameSize"
QT_MOC_LITERAL(37, 593, 9), // "frameSize"
QT_MOC_LITERAL(38, 603, 15), // "backgroundColor"
QT_MOC_LITERAL(39, 619, 7), // "filters"
QT_MOC_LITERAL(40, 627, 34), // "QQmlListProperty<QuickVideoFi..."
QT_MOC_LITERAL(41, 662, 10), // "brightness"
QT_MOC_LITERAL(42, 673, 8), // "contrast"
QT_MOC_LITERAL(43, 682, 3), // "hue"
QT_MOC_LITERAL(44, 686, 10), // "saturation"
QT_MOC_LITERAL(45, 697, 7), // "Stretch"
QT_MOC_LITERAL(46, 705, 17), // "PreserveAspectFit"
QT_MOC_LITERAL(47, 723, 18) // "PreserveAspectCrop"

    },
    "QtAV::QuickFBORenderer\0sourceChanged\0"
    "\0fillModeChanged\0QuickFBORenderer::FillMode\0"
    "orientationChanged\0contentRectChanged\0"
    "regionOfInterestChanged\0openGLChanged\0"
    "sourceAspectRatioChanged\0value\0"
    "videoFrameSizeChanged\0backgroundColorChanged\0"
    "brightnessChanged\0contrastChanged\0"
    "hueChanged\0saturationChanged\0"
    "mapPointToItem\0point\0mapRectToItem\0"
    "rectangle\0mapNormalizedPointToItem\0"
    "mapNormalizedRectToItem\0mapPointToSource\0"
    "mapRectToSource\0mapPointToSourceNormalized\0"
    "mapRectToSourceNormalized\0opengl\0"
    "source\0fillMode\0FillMode\0orientation\0"
    "contentRect\0sourceRect\0regionOfInterest\0"
    "sourceAspectRatio\0videoFrameSize\0"
    "frameSize\0backgroundColor\0filters\0"
    "QQmlListProperty<QuickVideoFilter>\0"
    "brightness\0contrast\0hue\0saturation\0"
    "Stretch\0PreserveAspectFit\0PreserveAspectCrop"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtAV__QuickFBORenderer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
      16,  168, // properties
       1,  232, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x06 /* Public */,
       3,    1,  120,    2, 0x06 /* Public */,
       5,    0,  123,    2, 0x06 /* Public */,
       6,    0,  124,    2, 0x06 /* Public */,
       7,    0,  125,    2, 0x06 /* Public */,
       8,    0,  126,    2, 0x06 /* Public */,
       9,    1,  127,    2, 0x06 /* Public */,
      11,    0,  130,    2, 0x06 /* Public */,
      12,    0,  131,    2, 0x06 /* Public */,
      13,    1,  132,    2, 0x06 /* Public */,
      14,    1,  135,    2, 0x06 /* Public */,
      15,    1,  138,    2, 0x06 /* Public */,
      16,    1,  141,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
      17,    1,  144,    2, 0x02 /* Public */,
      19,    1,  147,    2, 0x02 /* Public */,
      21,    1,  150,    2, 0x02 /* Public */,
      22,    1,  153,    2, 0x02 /* Public */,
      23,    1,  156,    2, 0x02 /* Public */,
      24,    1,  159,    2, 0x02 /* Public */,
      25,    1,  162,    2, 0x02 /* Public */,
      26,    1,  165,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,   10,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,
    QMetaType::Void, QMetaType::QReal,    2,

 // methods: parameters
    QMetaType::QPointF, QMetaType::QPointF,   18,
    QMetaType::QRectF, QMetaType::QRectF,   20,
    QMetaType::QPointF, QMetaType::QPointF,   18,
    QMetaType::QRectF, QMetaType::QRectF,   20,
    QMetaType::QPointF, QMetaType::QPointF,   18,
    QMetaType::QRectF, QMetaType::QRectF,   20,
    QMetaType::QPointF, QMetaType::QPointF,   18,
    QMetaType::QRectF, QMetaType::QRectF,   20,

 // properties: name, type, flags
      27, QMetaType::Bool, 0x00495003,
      28, QMetaType::QObjectStar, 0x00495103,
      29, 0x80000000 | 30, 0x0049510b,
      31, QMetaType::Int, 0x00495103,
      32, QMetaType::QRectF, 0x00495001,
      33, QMetaType::QRectF, 0x00495001,
      34, QMetaType::QRectF, 0x00495103,
      35, QMetaType::QReal, 0x00495001,
      36, QMetaType::QSize, 0x00495001,
      37, QMetaType::QSize, 0x00495001,
      38, QMetaType::QColor, 0x00495103,
      39, 0x80000000 | 40, 0x00095009,
      41, QMetaType::QReal, 0x00495103,
      42, QMetaType::QReal, 0x00495103,
      43, QMetaType::QReal, 0x00495103,
      44, QMetaType::QReal, 0x00495103,

 // properties: notify_signal_id
       5,
       0,
       1,
       2,
       3,
       7,
       4,
       6,
       7,
       7,
       8,
       0,
       9,
      10,
      11,
      12,

 // enums: name, alias, flags, count, data
      30,   30, 0x0,    3,  237,

 // enum data: key, value
      45, uint(QtAV::QuickFBORenderer::Stretch),
      46, uint(QtAV::QuickFBORenderer::PreserveAspectFit),
      47, uint(QtAV::QuickFBORenderer::PreserveAspectCrop),

       0        // eod
};

void QtAV::QuickFBORenderer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QuickFBORenderer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sourceChanged(); break;
        case 1: _t->fillModeChanged((*reinterpret_cast< QuickFBORenderer::FillMode(*)>(_a[1]))); break;
        case 2: _t->orientationChanged(); break;
        case 3: _t->contentRectChanged(); break;
        case 4: _t->regionOfInterestChanged(); break;
        case 5: _t->openGLChanged(); break;
        case 6: _t->sourceAspectRatioChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 7: _t->videoFrameSizeChanged(); break;
        case 8: _t->backgroundColorChanged(); break;
        case 9: _t->brightnessChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 10: _t->contrastChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 11: _t->hueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 12: _t->saturationChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 13: { QPointF _r = _t->mapPointToItem((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 14: { QRectF _r = _t->mapRectToItem((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        case 15: { QPointF _r = _t->mapNormalizedPointToItem((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 16: { QRectF _r = _t->mapNormalizedRectToItem((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        case 17: { QPointF _r = _t->mapPointToSource((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 18: { QRectF _r = _t->mapRectToSource((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        case 19: { QPointF _r = _t->mapPointToSourceNormalized((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 20: { QRectF _r = _t->mapRectToSourceNormalized((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::sourceChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)(QuickFBORenderer::FillMode );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::fillModeChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::orientationChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::contentRectChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::regionOfInterestChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::openGLChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::sourceAspectRatioChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::videoFrameSizeChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::backgroundColorChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::brightnessChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::contrastChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::hueChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (QuickFBORenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QuickFBORenderer::saturationChanged)) {
                *result = 12;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QuickFBORenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->isOpenGL(); break;
        case 1: *reinterpret_cast< QObject**>(_v) = _t->source(); break;
        case 2: *reinterpret_cast< FillMode*>(_v) = _t->fillMode(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->orientation(); break;
        case 4: *reinterpret_cast< QRectF*>(_v) = _t->contentRect(); break;
        case 5: *reinterpret_cast< QRectF*>(_v) = _t->sourceRect(); break;
        case 6: *reinterpret_cast< QRectF*>(_v) = _t->regionOfInterest(); break;
        case 7: *reinterpret_cast< qreal*>(_v) = _t->sourceAspectRatio(); break;
        case 8: *reinterpret_cast< QSize*>(_v) = _t->videoFrameSize(); break;
        case 9: *reinterpret_cast< QSize*>(_v) = _t->videoFrameSize(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->backgroundColor(); break;
        case 11: *reinterpret_cast< QQmlListProperty<QuickVideoFilter>*>(_v) = _t->filters(); break;
        case 12: *reinterpret_cast< qreal*>(_v) = _t->brightness(); break;
        case 13: *reinterpret_cast< qreal*>(_v) = _t->contrast(); break;
        case 14: *reinterpret_cast< qreal*>(_v) = _t->hue(); break;
        case 15: *reinterpret_cast< qreal*>(_v) = _t->saturation(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QuickFBORenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setOpenGL(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setSource(*reinterpret_cast< QObject**>(_v)); break;
        case 2: _t->setFillMode(*reinterpret_cast< FillMode*>(_v)); break;
        case 3: _t->setOrientation(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setRegionOfInterest(*reinterpret_cast< QRectF*>(_v)); break;
        case 10: _t->setBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 12: _t->setBrightness(*reinterpret_cast< qreal*>(_v)); break;
        case 13: _t->setContrast(*reinterpret_cast< qreal*>(_v)); break;
        case 14: _t->setHue(*reinterpret_cast< qreal*>(_v)); break;
        case 15: _t->setSaturation(*reinterpret_cast< qreal*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtAV::QuickFBORenderer::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickFramebufferObject::staticMetaObject>(),
    qt_meta_stringdata_QtAV__QuickFBORenderer.data,
    qt_meta_data_QtAV__QuickFBORenderer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtAV::QuickFBORenderer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtAV::QuickFBORenderer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtAV__QuickFBORenderer.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "VideoRenderer"))
        return static_cast< VideoRenderer*>(this);
    return QQuickFramebufferObject::qt_metacast(_clname);
}

int QtAV::QuickFBORenderer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickFramebufferObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 21;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 16;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 16;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtAV::QuickFBORenderer::sourceChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QtAV::QuickFBORenderer::fillModeChanged(QuickFBORenderer::FillMode _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QtAV::QuickFBORenderer::orientationChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QtAV::QuickFBORenderer::contentRectChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QtAV::QuickFBORenderer::regionOfInterestChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QtAV::QuickFBORenderer::openGLChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QtAV::QuickFBORenderer::sourceAspectRatioChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QtAV::QuickFBORenderer::videoFrameSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QtAV::QuickFBORenderer::backgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QtAV::QuickFBORenderer::brightnessChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void QtAV::QuickFBORenderer::contrastChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void QtAV::QuickFBORenderer::hueChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void QtAV::QuickFBORenderer::saturationChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
