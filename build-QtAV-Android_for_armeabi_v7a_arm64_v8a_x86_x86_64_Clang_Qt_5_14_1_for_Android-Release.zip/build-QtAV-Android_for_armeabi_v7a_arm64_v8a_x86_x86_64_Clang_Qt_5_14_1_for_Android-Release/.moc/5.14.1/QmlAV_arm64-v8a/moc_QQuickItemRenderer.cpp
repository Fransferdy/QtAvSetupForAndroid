/****************************************************************************
** Meta object code from reading C++ file 'QQuickItemRenderer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/qml/QmlAV/QQuickItemRenderer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QQuickItemRenderer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QtAV__QQuickItemRenderer_t {
    QByteArrayData data[45];
    char stringdata0[716];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QtAV__QQuickItemRenderer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QtAV__QQuickItemRenderer_t qt_meta_stringdata_QtAV__QQuickItemRenderer = {
    {
QT_MOC_LITERAL(0, 0, 24), // "QtAV::QQuickItemRenderer"
QT_MOC_LITERAL(1, 25, 13), // "sourceChanged"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 15), // "fillModeChanged"
QT_MOC_LITERAL(4, 56, 28), // "QQuickItemRenderer::FillMode"
QT_MOC_LITERAL(5, 85, 18), // "orientationChanged"
QT_MOC_LITERAL(6, 104, 18), // "contentRectChanged"
QT_MOC_LITERAL(7, 123, 23), // "regionOfInterestChanged"
QT_MOC_LITERAL(8, 147, 13), // "openGLChanged"
QT_MOC_LITERAL(9, 161, 24), // "sourceAspectRatioChanged"
QT_MOC_LITERAL(10, 186, 5), // "value"
QT_MOC_LITERAL(11, 192, 21), // "videoFrameSizeChanged"
QT_MOC_LITERAL(12, 214, 22), // "backgroundColorChanged"
QT_MOC_LITERAL(13, 237, 18), // "handleWindowChange"
QT_MOC_LITERAL(14, 256, 13), // "QQuickWindow*"
QT_MOC_LITERAL(15, 270, 3), // "win"
QT_MOC_LITERAL(16, 274, 15), // "beforeRendering"
QT_MOC_LITERAL(17, 290, 14), // "afterRendering"
QT_MOC_LITERAL(18, 305, 14), // "mapPointToItem"
QT_MOC_LITERAL(19, 320, 5), // "point"
QT_MOC_LITERAL(20, 326, 13), // "mapRectToItem"
QT_MOC_LITERAL(21, 340, 9), // "rectangle"
QT_MOC_LITERAL(22, 350, 24), // "mapNormalizedPointToItem"
QT_MOC_LITERAL(23, 375, 23), // "mapNormalizedRectToItem"
QT_MOC_LITERAL(24, 399, 16), // "mapPointToSource"
QT_MOC_LITERAL(25, 416, 15), // "mapRectToSource"
QT_MOC_LITERAL(26, 432, 26), // "mapPointToSourceNormalized"
QT_MOC_LITERAL(27, 459, 25), // "mapRectToSourceNormalized"
QT_MOC_LITERAL(28, 485, 6), // "opengl"
QT_MOC_LITERAL(29, 492, 6), // "source"
QT_MOC_LITERAL(30, 499, 8), // "fillMode"
QT_MOC_LITERAL(31, 508, 8), // "FillMode"
QT_MOC_LITERAL(32, 517, 11), // "orientation"
QT_MOC_LITERAL(33, 529, 11), // "contentRect"
QT_MOC_LITERAL(34, 541, 10), // "sourceRect"
QT_MOC_LITERAL(35, 552, 16), // "regionOfInterest"
QT_MOC_LITERAL(36, 569, 17), // "sourceAspectRatio"
QT_MOC_LITERAL(37, 587, 14), // "videoFrameSize"
QT_MOC_LITERAL(38, 602, 9), // "frameSize"
QT_MOC_LITERAL(39, 612, 15), // "backgroundColor"
QT_MOC_LITERAL(40, 628, 7), // "filters"
QT_MOC_LITERAL(41, 636, 34), // "QQmlListProperty<QuickVideoFi..."
QT_MOC_LITERAL(42, 671, 7), // "Stretch"
QT_MOC_LITERAL(43, 679, 17), // "PreserveAspectFit"
QT_MOC_LITERAL(44, 697, 18) // "PreserveAspectCrop"

    },
    "QtAV::QQuickItemRenderer\0sourceChanged\0"
    "\0fillModeChanged\0QQuickItemRenderer::FillMode\0"
    "orientationChanged\0contentRectChanged\0"
    "regionOfInterestChanged\0openGLChanged\0"
    "sourceAspectRatioChanged\0value\0"
    "videoFrameSizeChanged\0backgroundColorChanged\0"
    "handleWindowChange\0QQuickWindow*\0win\0"
    "beforeRendering\0afterRendering\0"
    "mapPointToItem\0point\0mapRectToItem\0"
    "rectangle\0mapNormalizedPointToItem\0"
    "mapNormalizedRectToItem\0mapPointToSource\0"
    "mapRectToSource\0mapPointToSourceNormalized\0"
    "mapRectToSourceNormalized\0opengl\0"
    "source\0fillMode\0FillMode\0orientation\0"
    "contentRect\0sourceRect\0regionOfInterest\0"
    "sourceAspectRatio\0videoFrameSize\0"
    "frameSize\0backgroundColor\0filters\0"
    "QQmlListProperty<QuickVideoFilter>\0"
    "Stretch\0PreserveAspectFit\0PreserveAspectCrop"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QtAV__QQuickItemRenderer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
      12,  156, // properties
       1,  204, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x06 /* Public */,
       3,    1,  115,    2, 0x06 /* Public */,
       5,    0,  118,    2, 0x06 /* Public */,
       6,    0,  119,    2, 0x06 /* Public */,
       7,    0,  120,    2, 0x06 /* Public */,
       8,    0,  121,    2, 0x06 /* Public */,
       9,    1,  122,    2, 0x06 /* Public */,
      11,    0,  125,    2, 0x06 /* Public */,
      12,    0,  126,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    1,  127,    2, 0x08 /* Private */,
      16,    0,  130,    2, 0x08 /* Private */,
      17,    0,  131,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
      18,    1,  132,    2, 0x02 /* Public */,
      20,    1,  135,    2, 0x02 /* Public */,
      22,    1,  138,    2, 0x02 /* Public */,
      23,    1,  141,    2, 0x02 /* Public */,
      24,    1,  144,    2, 0x02 /* Public */,
      25,    1,  147,    2, 0x02 /* Public */,
      26,    1,  150,    2, 0x02 /* Public */,
      27,    1,  153,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,   10,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::QPointF, QMetaType::QPointF,   19,
    QMetaType::QRectF, QMetaType::QRectF,   21,
    QMetaType::QPointF, QMetaType::QPointF,   19,
    QMetaType::QRectF, QMetaType::QRectF,   21,
    QMetaType::QPointF, QMetaType::QPointF,   19,
    QMetaType::QRectF, QMetaType::QRectF,   21,
    QMetaType::QPointF, QMetaType::QPointF,   19,
    QMetaType::QRectF, QMetaType::QRectF,   21,

 // properties: name, type, flags
      28, QMetaType::Bool, 0x00495003,
      29, QMetaType::QObjectStar, 0x00495103,
      30, 0x80000000 | 31, 0x0049510b,
      32, QMetaType::Int, 0x00495103,
      33, QMetaType::QRectF, 0x00495001,
      34, QMetaType::QRectF, 0x00495001,
      35, QMetaType::QRectF, 0x00495103,
      36, QMetaType::QReal, 0x00495001,
      37, QMetaType::QSize, 0x00495001,
      38, QMetaType::QSize, 0x00495001,
      39, QMetaType::QColor, 0x00495103,
      40, 0x80000000 | 41, 0x00095009,

 // properties: notify_signal_id
       5,
       0,
       1,
       2,
       3,
       7,
       4,
       6,
       7,
       7,
       8,
       0,

 // enums: name, alias, flags, count, data
      31,   31, 0x0,    3,  209,

 // enum data: key, value
      42, uint(QtAV::QQuickItemRenderer::Stretch),
      43, uint(QtAV::QQuickItemRenderer::PreserveAspectFit),
      44, uint(QtAV::QQuickItemRenderer::PreserveAspectCrop),

       0        // eod
};

void QtAV::QQuickItemRenderer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QQuickItemRenderer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sourceChanged(); break;
        case 1: _t->fillModeChanged((*reinterpret_cast< QQuickItemRenderer::FillMode(*)>(_a[1]))); break;
        case 2: _t->orientationChanged(); break;
        case 3: _t->contentRectChanged(); break;
        case 4: _t->regionOfInterestChanged(); break;
        case 5: _t->openGLChanged(); break;
        case 6: _t->sourceAspectRatioChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 7: _t->videoFrameSizeChanged(); break;
        case 8: _t->backgroundColorChanged(); break;
        case 9: _t->handleWindowChange((*reinterpret_cast< QQuickWindow*(*)>(_a[1]))); break;
        case 10: _t->beforeRendering(); break;
        case 11: _t->afterRendering(); break;
        case 12: { QPointF _r = _t->mapPointToItem((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 13: { QRectF _r = _t->mapRectToItem((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        case 14: { QPointF _r = _t->mapNormalizedPointToItem((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 15: { QRectF _r = _t->mapNormalizedRectToItem((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        case 16: { QPointF _r = _t->mapPointToSource((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 17: { QRectF _r = _t->mapRectToSource((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        case 18: { QPointF _r = _t->mapPointToSourceNormalized((*reinterpret_cast< const QPointF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QPointF*>(_a[0]) = std::move(_r); }  break;
        case 19: { QRectF _r = _t->mapRectToSourceNormalized((*reinterpret_cast< const QRectF(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QRectF*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::sourceChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)(QQuickItemRenderer::FillMode );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::fillModeChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::orientationChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::contentRectChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::regionOfInterestChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::openGLChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)(qreal );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::sourceAspectRatioChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::videoFrameSizeChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QQuickItemRenderer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QQuickItemRenderer::backgroundColorChanged)) {
                *result = 8;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QQuickItemRenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->isOpenGL(); break;
        case 1: *reinterpret_cast< QObject**>(_v) = _t->source(); break;
        case 2: *reinterpret_cast< FillMode*>(_v) = _t->fillMode(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->orientation(); break;
        case 4: *reinterpret_cast< QRectF*>(_v) = _t->contentRect(); break;
        case 5: *reinterpret_cast< QRectF*>(_v) = _t->sourceRect(); break;
        case 6: *reinterpret_cast< QRectF*>(_v) = _t->regionOfInterest(); break;
        case 7: *reinterpret_cast< qreal*>(_v) = _t->sourceAspectRatio(); break;
        case 8: *reinterpret_cast< QSize*>(_v) = _t->videoFrameSize(); break;
        case 9: *reinterpret_cast< QSize*>(_v) = _t->videoFrameSize(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->backgroundColor(); break;
        case 11: *reinterpret_cast< QQmlListProperty<QuickVideoFilter>*>(_v) = _t->filters(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QQuickItemRenderer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setOpenGL(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setSource(*reinterpret_cast< QObject**>(_v)); break;
        case 2: _t->setFillMode(*reinterpret_cast< FillMode*>(_v)); break;
        case 3: _t->setOrientation(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setRegionOfInterest(*reinterpret_cast< QRectF*>(_v)); break;
        case 10: _t->setBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QtAV::QQuickItemRenderer::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickItem::staticMetaObject>(),
    qt_meta_stringdata_QtAV__QQuickItemRenderer.data,
    qt_meta_data_QtAV__QQuickItemRenderer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QtAV::QQuickItemRenderer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QtAV::QQuickItemRenderer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QtAV__QQuickItemRenderer.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "VideoRenderer"))
        return static_cast< VideoRenderer*>(this);
    return QQuickItem::qt_metacast(_clname);
}

int QtAV::QQuickItemRenderer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 12;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QtAV::QQuickItemRenderer::sourceChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QtAV::QQuickItemRenderer::fillModeChanged(QQuickItemRenderer::FillMode _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QtAV::QQuickItemRenderer::orientationChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QtAV::QQuickItemRenderer::contentRectChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QtAV::QQuickItemRenderer::regionOfInterestChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QtAV::QQuickItemRenderer::openGLChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QtAV::QQuickItemRenderer::sourceAspectRatioChanged(qreal _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QtAV::QQuickItemRenderer::videoFrameSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QtAV::QQuickItemRenderer::backgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
