/****************************************************************************
** Meta object code from reading C++ file 'QmlAVPlayer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/qml/QmlAV/QmlAVPlayer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'QmlAVPlayer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QmlAVPlayer_t {
    QByteArrayData data[156];
    char stringdata0[2211];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QmlAVPlayer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QmlAVPlayer_t qt_meta_stringdata_QmlAVPlayer = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QmlAVPlayer"
QT_MOC_LITERAL(1, 12, 13), // "volumeChanged"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 12), // "mutedChanged"
QT_MOC_LITERAL(4, 40, 15), // "hasAudioChanged"
QT_MOC_LITERAL(5, 56, 15), // "hasVideoChanged"
QT_MOC_LITERAL(6, 72, 15), // "durationChanged"
QT_MOC_LITERAL(7, 88, 15), // "positionChanged"
QT_MOC_LITERAL(8, 104, 13), // "sourceChanged"
QT_MOC_LITERAL(9, 118, 15), // "autoLoadChanged"
QT_MOC_LITERAL(10, 134, 16), // "loopCountChanged"
QT_MOC_LITERAL(11, 151, 15), // "videoOutChanged"
QT_MOC_LITERAL(12, 167, 20), // "playbackStateChanged"
QT_MOC_LITERAL(13, 188, 15), // "autoPlayChanged"
QT_MOC_LITERAL(14, 204, 19), // "playbackRateChanged"
QT_MOC_LITERAL(15, 224, 6), // "paused"
QT_MOC_LITERAL(16, 231, 7), // "stopped"
QT_MOC_LITERAL(17, 239, 7), // "playing"
QT_MOC_LITERAL(18, 247, 20), // "startPositionChanged"
QT_MOC_LITERAL(19, 268, 19), // "stopPositionChanged"
QT_MOC_LITERAL(20, 288, 15), // "seekableChanged"
QT_MOC_LITERAL(21, 304, 12), // "seekFinished"
QT_MOC_LITERAL(22, 317, 15), // "fastSeekChanged"
QT_MOC_LITERAL(23, 333, 21), // "bufferProgressChanged"
QT_MOC_LITERAL(24, 355, 25), // "videoCodecPriorityChanged"
QT_MOC_LITERAL(25, 381, 24), // "videoCodecOptionsChanged"
QT_MOC_LITERAL(26, 406, 22), // "avFormatOptionsChanged"
QT_MOC_LITERAL(27, 429, 31), // "useWallclockAsTimestampsChanged"
QT_MOC_LITERAL(28, 461, 20), // "channelLayoutChanged"
QT_MOC_LITERAL(29, 482, 14), // "timeoutChanged"
QT_MOC_LITERAL(30, 497, 21), // "abortOnTimeoutChanged"
QT_MOC_LITERAL(31, 519, 17), // "audioTrackChanged"
QT_MOC_LITERAL(32, 537, 26), // "internalAudioTracksChanged"
QT_MOC_LITERAL(33, 564, 17), // "videoTrackChanged"
QT_MOC_LITERAL(34, 582, 26), // "internalVideoTracksChanged"
QT_MOC_LITERAL(35, 609, 20), // "externalAudioChanged"
QT_MOC_LITERAL(36, 630, 26), // "externalAudioTracksChanged"
QT_MOC_LITERAL(37, 657, 28), // "internalSubtitleTrackChanged"
QT_MOC_LITERAL(38, 686, 29), // "internalSubtitleTracksChanged"
QT_MOC_LITERAL(39, 716, 17), // "bufferSizeChanged"
QT_MOC_LITERAL(40, 734, 17), // "bufferModeChanged"
QT_MOC_LITERAL(41, 752, 16), // "frameRateChanged"
QT_MOC_LITERAL(42, 769, 21), // "mediaEndActionChanged"
QT_MOC_LITERAL(43, 791, 12), // "errorChanged"
QT_MOC_LITERAL(44, 804, 5), // "error"
QT_MOC_LITERAL(45, 810, 5), // "Error"
QT_MOC_LITERAL(46, 816, 11), // "errorString"
QT_MOC_LITERAL(47, 828, 13), // "statusChanged"
QT_MOC_LITERAL(48, 842, 18), // "mediaObjectChanged"
QT_MOC_LITERAL(49, 861, 20), // "audioBackendsChanged"
QT_MOC_LITERAL(50, 882, 4), // "play"
QT_MOC_LITERAL(51, 887, 5), // "pause"
QT_MOC_LITERAL(52, 893, 4), // "stop"
QT_MOC_LITERAL(53, 898, 11), // "stepForward"
QT_MOC_LITERAL(54, 910, 12), // "stepBackward"
QT_MOC_LITERAL(55, 923, 4), // "seek"
QT_MOC_LITERAL(56, 928, 6), // "offset"
QT_MOC_LITERAL(57, 935, 11), // "seekForward"
QT_MOC_LITERAL(58, 947, 12), // "seekBackward"
QT_MOC_LITERAL(59, 960, 8), // "_q_error"
QT_MOC_LITERAL(60, 969, 13), // "QtAV::AVError"
QT_MOC_LITERAL(61, 983, 1), // "e"
QT_MOC_LITERAL(62, 985, 16), // "_q_statusChanged"
QT_MOC_LITERAL(63, 1002, 10), // "_q_started"
QT_MOC_LITERAL(64, 1013, 10), // "_q_stopped"
QT_MOC_LITERAL(65, 1024, 9), // "_q_paused"
QT_MOC_LITERAL(66, 1034, 11), // "applyVolume"
QT_MOC_LITERAL(67, 1046, 18), // "applyChannelLayout"
QT_MOC_LITERAL(68, 1065, 3), // "url"
QT_MOC_LITERAL(69, 1069, 6), // "volume"
QT_MOC_LITERAL(70, 1076, 6), // "status"
QT_MOC_LITERAL(71, 1083, 6), // "Status"
QT_MOC_LITERAL(72, 1090, 8), // "duration"
QT_MOC_LITERAL(73, 1099, 8), // "position"
QT_MOC_LITERAL(74, 1108, 5), // "muted"
QT_MOC_LITERAL(75, 1114, 8), // "hasAudio"
QT_MOC_LITERAL(76, 1123, 8), // "hasVideo"
QT_MOC_LITERAL(77, 1132, 13), // "playbackState"
QT_MOC_LITERAL(78, 1146, 13), // "PlaybackState"
QT_MOC_LITERAL(79, 1160, 8), // "autoPlay"
QT_MOC_LITERAL(80, 1169, 8), // "autoLoad"
QT_MOC_LITERAL(81, 1178, 12), // "playbackRate"
QT_MOC_LITERAL(82, 1191, 6), // "source"
QT_MOC_LITERAL(83, 1198, 5), // "loops"
QT_MOC_LITERAL(84, 1204, 14), // "bufferProgress"
QT_MOC_LITERAL(85, 1219, 8), // "seekable"
QT_MOC_LITERAL(86, 1228, 8), // "metaData"
QT_MOC_LITERAL(87, 1237, 14), // "MediaMetaData*"
QT_MOC_LITERAL(88, 1252, 11), // "mediaObject"
QT_MOC_LITERAL(89, 1264, 13), // "startPosition"
QT_MOC_LITERAL(90, 1278, 12), // "stopPosition"
QT_MOC_LITERAL(91, 1291, 8), // "fastSeek"
QT_MOC_LITERAL(92, 1300, 7), // "timeout"
QT_MOC_LITERAL(93, 1308, 14), // "abortOnTimeout"
QT_MOC_LITERAL(94, 1323, 13), // "channelLayout"
QT_MOC_LITERAL(95, 1337, 13), // "ChannelLayout"
QT_MOC_LITERAL(96, 1351, 11), // "videoCodecs"
QT_MOC_LITERAL(97, 1363, 18), // "videoCodecPriority"
QT_MOC_LITERAL(98, 1382, 17), // "videoCodecOptions"
QT_MOC_LITERAL(99, 1400, 15), // "avFormatOptions"
QT_MOC_LITERAL(100, 1416, 24), // "useWallclockAsTimestamps"
QT_MOC_LITERAL(101, 1441, 12), // "videoCapture"
QT_MOC_LITERAL(102, 1454, 19), // "QtAV::VideoCapture*"
QT_MOC_LITERAL(103, 1474, 10), // "audioTrack"
QT_MOC_LITERAL(104, 1485, 10), // "videoTrack"
QT_MOC_LITERAL(105, 1496, 10), // "bufferSize"
QT_MOC_LITERAL(106, 1507, 10), // "bufferMode"
QT_MOC_LITERAL(107, 1518, 10), // "BufferMode"
QT_MOC_LITERAL(108, 1529, 9), // "frameRate"
QT_MOC_LITERAL(109, 1539, 13), // "externalAudio"
QT_MOC_LITERAL(110, 1553, 19), // "internalAudioTracks"
QT_MOC_LITERAL(111, 1573, 19), // "internalVideoTracks"
QT_MOC_LITERAL(112, 1593, 19), // "externalAudioTracks"
QT_MOC_LITERAL(113, 1613, 22), // "internalSubtitleTracks"
QT_MOC_LITERAL(114, 1636, 21), // "internalSubtitleTrack"
QT_MOC_LITERAL(115, 1658, 14), // "mediaEndAction"
QT_MOC_LITERAL(116, 1673, 14), // "MediaEndAction"
QT_MOC_LITERAL(117, 1688, 12), // "audioFilters"
QT_MOC_LITERAL(118, 1701, 34), // "QQmlListProperty<QuickAudioFi..."
QT_MOC_LITERAL(119, 1736, 12), // "videoFilters"
QT_MOC_LITERAL(120, 1749, 34), // "QQmlListProperty<QuickVideoFi..."
QT_MOC_LITERAL(121, 1784, 13), // "audioBackends"
QT_MOC_LITERAL(122, 1798, 22), // "supportedAudioBackends"
QT_MOC_LITERAL(123, 1821, 4), // "Loop"
QT_MOC_LITERAL(124, 1826, 8), // "Infinite"
QT_MOC_LITERAL(125, 1835, 13), // "PositionValue"
QT_MOC_LITERAL(126, 1849, 11), // "PositionMax"
QT_MOC_LITERAL(127, 1861, 12), // "StoppedState"
QT_MOC_LITERAL(128, 1874, 12), // "PlayingState"
QT_MOC_LITERAL(129, 1887, 11), // "PausedState"
QT_MOC_LITERAL(130, 1899, 13), // "UnknownStatus"
QT_MOC_LITERAL(131, 1913, 7), // "NoMedia"
QT_MOC_LITERAL(132, 1921, 7), // "Loading"
QT_MOC_LITERAL(133, 1929, 6), // "Loaded"
QT_MOC_LITERAL(134, 1936, 7), // "Stalled"
QT_MOC_LITERAL(135, 1944, 9), // "Buffering"
QT_MOC_LITERAL(136, 1954, 8), // "Buffered"
QT_MOC_LITERAL(137, 1963, 10), // "EndOfMedia"
QT_MOC_LITERAL(138, 1974, 12), // "InvalidMedia"
QT_MOC_LITERAL(139, 1987, 7), // "NoError"
QT_MOC_LITERAL(140, 1995, 13), // "ResourceError"
QT_MOC_LITERAL(141, 2009, 11), // "FormatError"
QT_MOC_LITERAL(142, 2021, 12), // "NetworkError"
QT_MOC_LITERAL(143, 2034, 12), // "AccessDenied"
QT_MOC_LITERAL(144, 2047, 14), // "ServiceMissing"
QT_MOC_LITERAL(145, 2062, 17), // "ChannelLayoutAuto"
QT_MOC_LITERAL(146, 2080, 4), // "Left"
QT_MOC_LITERAL(147, 2085, 5), // "Right"
QT_MOC_LITERAL(148, 2091, 4), // "Mono"
QT_MOC_LITERAL(149, 2096, 6), // "Stereo"
QT_MOC_LITERAL(150, 2103, 10), // "BufferTime"
QT_MOC_LITERAL(151, 2114, 11), // "BufferBytes"
QT_MOC_LITERAL(152, 2126, 13), // "BufferPackets"
QT_MOC_LITERAL(153, 2140, 22), // "MediaEndAction_Default"
QT_MOC_LITERAL(154, 2163, 26), // "MediaEndAction_KeepDisplay"
QT_MOC_LITERAL(155, 2190, 20) // "MediaEndAction_Pause"

    },
    "QmlAVPlayer\0volumeChanged\0\0mutedChanged\0"
    "hasAudioChanged\0hasVideoChanged\0"
    "durationChanged\0positionChanged\0"
    "sourceChanged\0autoLoadChanged\0"
    "loopCountChanged\0videoOutChanged\0"
    "playbackStateChanged\0autoPlayChanged\0"
    "playbackRateChanged\0paused\0stopped\0"
    "playing\0startPositionChanged\0"
    "stopPositionChanged\0seekableChanged\0"
    "seekFinished\0fastSeekChanged\0"
    "bufferProgressChanged\0videoCodecPriorityChanged\0"
    "videoCodecOptionsChanged\0"
    "avFormatOptionsChanged\0"
    "useWallclockAsTimestampsChanged\0"
    "channelLayoutChanged\0timeoutChanged\0"
    "abortOnTimeoutChanged\0audioTrackChanged\0"
    "internalAudioTracksChanged\0videoTrackChanged\0"
    "internalVideoTracksChanged\0"
    "externalAudioChanged\0externalAudioTracksChanged\0"
    "internalSubtitleTrackChanged\0"
    "internalSubtitleTracksChanged\0"
    "bufferSizeChanged\0bufferModeChanged\0"
    "frameRateChanged\0mediaEndActionChanged\0"
    "errorChanged\0error\0Error\0errorString\0"
    "statusChanged\0mediaObjectChanged\0"
    "audioBackendsChanged\0play\0pause\0stop\0"
    "stepForward\0stepBackward\0seek\0offset\0"
    "seekForward\0seekBackward\0_q_error\0"
    "QtAV::AVError\0e\0_q_statusChanged\0"
    "_q_started\0_q_stopped\0_q_paused\0"
    "applyVolume\0applyChannelLayout\0url\0"
    "volume\0status\0Status\0duration\0position\0"
    "muted\0hasAudio\0hasVideo\0playbackState\0"
    "PlaybackState\0autoPlay\0autoLoad\0"
    "playbackRate\0source\0loops\0bufferProgress\0"
    "seekable\0metaData\0MediaMetaData*\0"
    "mediaObject\0startPosition\0stopPosition\0"
    "fastSeek\0timeout\0abortOnTimeout\0"
    "channelLayout\0ChannelLayout\0videoCodecs\0"
    "videoCodecPriority\0videoCodecOptions\0"
    "avFormatOptions\0useWallclockAsTimestamps\0"
    "videoCapture\0QtAV::VideoCapture*\0"
    "audioTrack\0videoTrack\0bufferSize\0"
    "bufferMode\0BufferMode\0frameRate\0"
    "externalAudio\0internalAudioTracks\0"
    "internalVideoTracks\0externalAudioTracks\0"
    "internalSubtitleTracks\0internalSubtitleTrack\0"
    "mediaEndAction\0MediaEndAction\0"
    "audioFilters\0QQmlListProperty<QuickAudioFilter>\0"
    "videoFilters\0QQmlListProperty<QuickVideoFilter>\0"
    "audioBackends\0supportedAudioBackends\0"
    "Loop\0Infinite\0PositionValue\0PositionMax\0"
    "StoppedState\0PlayingState\0PausedState\0"
    "UnknownStatus\0NoMedia\0Loading\0Loaded\0"
    "Stalled\0Buffering\0Buffered\0EndOfMedia\0"
    "InvalidMedia\0NoError\0ResourceError\0"
    "FormatError\0NetworkError\0AccessDenied\0"
    "ServiceMissing\0ChannelLayoutAuto\0Left\0"
    "Right\0Mono\0Stereo\0BufferTime\0BufferBytes\0"
    "BufferPackets\0MediaEndAction_Default\0"
    "MediaEndAction_KeepDisplay\0"
    "MediaEndAction_Pause"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QmlAVPlayer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      62,   14, // methods
      47,  398, // properties
       8,  586, // enums/sets
       0,    0, // constructors
       0,       // flags
      46,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  324,    2, 0x06 /* Public */,
       3,    0,  325,    2, 0x06 /* Public */,
       4,    0,  326,    2, 0x06 /* Public */,
       5,    0,  327,    2, 0x06 /* Public */,
       6,    0,  328,    2, 0x06 /* Public */,
       7,    0,  329,    2, 0x06 /* Public */,
       8,    0,  330,    2, 0x06 /* Public */,
       9,    0,  331,    2, 0x06 /* Public */,
      10,    0,  332,    2, 0x06 /* Public */,
      11,    0,  333,    2, 0x06 /* Public */,
      12,    0,  334,    2, 0x06 /* Public */,
      13,    0,  335,    2, 0x06 /* Public */,
      14,    0,  336,    2, 0x06 /* Public */,
      15,    0,  337,    2, 0x06 /* Public */,
      16,    0,  338,    2, 0x06 /* Public */,
      17,    0,  339,    2, 0x06 /* Public */,
      18,    0,  340,    2, 0x06 /* Public */,
      19,    0,  341,    2, 0x06 /* Public */,
      20,    0,  342,    2, 0x06 /* Public */,
      21,    0,  343,    2, 0x06 /* Public */,
      22,    0,  344,    2, 0x06 /* Public */,
      23,    0,  345,    2, 0x06 /* Public */,
      24,    0,  346,    2, 0x06 /* Public */,
      25,    0,  347,    2, 0x06 /* Public */,
      26,    0,  348,    2, 0x06 /* Public */,
      27,    0,  349,    2, 0x06 /* Public */,
      28,    0,  350,    2, 0x06 /* Public */,
      29,    0,  351,    2, 0x06 /* Public */,
      30,    0,  352,    2, 0x06 /* Public */,
      31,    0,  353,    2, 0x06 /* Public */,
      32,    0,  354,    2, 0x06 /* Public */,
      33,    0,  355,    2, 0x06 /* Public */,
      34,    0,  356,    2, 0x06 /* Public */,
      35,    0,  357,    2, 0x06 /* Public */,
      36,    0,  358,    2, 0x06 /* Public */,
      37,    0,  359,    2, 0x06 /* Public */,
      38,    0,  360,    2, 0x06 /* Public */,
      39,    0,  361,    2, 0x06 /* Public */,
      40,    0,  362,    2, 0x06 /* Public */,
      41,    0,  363,    2, 0x06 /* Public */,
      42,    0,  364,    2, 0x06 /* Public */,
      43,    0,  365,    2, 0x06 /* Public */,
      44,    2,  366,    2, 0x06 /* Public */,
      47,    0,  371,    2, 0x06 /* Public */,
      48,    0,  372,    2, 0x06 /* Public */,
      49,    0,  373,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      50,    0,  374,    2, 0x0a /* Public */,
      51,    0,  375,    2, 0x0a /* Public */,
      52,    0,  376,    2, 0x0a /* Public */,
      53,    0,  377,    2, 0x0a /* Public */,
      54,    0,  378,    2, 0x0a /* Public */,
      55,    1,  379,    2, 0x0a /* Public */,
      57,    0,  382,    2, 0x0a /* Public */,
      58,    0,  383,    2, 0x0a /* Public */,
      59,    1,  384,    2, 0x08 /* Private */,
      62,    0,  387,    2, 0x08 /* Private */,
      63,    0,  388,    2, 0x08 /* Private */,
      64,    0,  389,    2, 0x08 /* Private */,
      65,    1,  390,    2, 0x08 /* Private */,
      66,    0,  393,    2, 0x08 /* Private */,
      67,    0,  394,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
      50,    1,  395,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 45, QMetaType::QString,   44,   46,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   56,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 60,   61,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void, QMetaType::QUrl,   68,

 // properties: name, type, flags
      69, QMetaType::QReal, 0x00495103,
      70, 0x80000000 | 71, 0x00495009,
      44, 0x80000000 | 45, 0x00495009,
      72, QMetaType::Int, 0x00495001,
      73, QMetaType::Int, 0x00495001,
      74, QMetaType::Bool, 0x00495103,
      75, QMetaType::Bool, 0x00495001,
      76, QMetaType::Bool, 0x00495001,
      77, 0x80000000 | 78, 0x00495009,
      79, QMetaType::Bool, 0x00495103,
      80, QMetaType::Bool, 0x00495103,
      81, QMetaType::QReal, 0x00495103,
      82, QMetaType::QUrl, 0x00495103,
      83, QMetaType::Int, 0x00495003,
      84, QMetaType::QReal, 0x00495001,
      85, QMetaType::Bool, 0x00495001,
      86, 0x80000000 | 87, 0x00095409,
      88, QMetaType::QObjectStar, 0x00490001,
      46, QMetaType::QString, 0x00495001,
      89, QMetaType::Int, 0x00495103,
      90, QMetaType::Int, 0x00495103,
      91, QMetaType::Bool, 0x00495103,
      92, QMetaType::Int, 0x00495103,
      93, QMetaType::Bool, 0x00495103,
      94, 0x80000000 | 95, 0x0049510b,
      96, QMetaType::QStringList, 0x00095001,
      97, QMetaType::QStringList, 0x00495103,
      98, QMetaType::QVariantMap, 0x00495103,
      99, QMetaType::QVariantMap, 0x00495003,
     100, QMetaType::Bool, 0x00495003,
     101, 0x80000000 | 102, 0x00095409,
     103, QMetaType::Int, 0x00495103,
     104, QMetaType::Int, 0x00495103,
     105, QMetaType::Int, 0x00495103,
     106, 0x80000000 | 107, 0x0049510b,
     108, QMetaType::QReal, 0x00495103,
     109, QMetaType::QUrl, 0x00495103,
     110, QMetaType::QVariantList, 0x00495001,
     111, QMetaType::QVariantList, 0x00495001,
     112, QMetaType::QVariantList, 0x00495001,
     113, QMetaType::QVariantList, 0x00495001,
     114, QMetaType::Int, 0x00495103,
     115, 0x80000000 | 116, 0x0049510b,
     117, 0x80000000 | 118, 0x00095009,
     119, 0x80000000 | 120, 0x00095009,
     121, QMetaType::QStringList, 0x00495103,
     122, QMetaType::QStringList, 0x00095001,

 // properties: notify_signal_id
       0,
      43,
      41,
       4,
       5,
       1,
       2,
       3,
      10,
      11,
       7,
      12,
       6,
       8,
      21,
      18,
       0,
      44,
      41,
      16,
      17,
      20,
      27,
      28,
      26,
       0,
      22,
      23,
      24,
      25,
       0,
      29,
      31,
      37,
      38,
      39,
      33,
      30,
      32,
      34,
      36,
      35,
      40,
       0,
       0,
      45,
       0,

 // enums: name, alias, flags, count, data
     123,  123, 0x0,    1,  626,
     125,  125, 0x0,    1,  628,
      78,   78, 0x0,    3,  630,
      71,   71, 0x0,    9,  636,
      45,   45, 0x0,    6,  654,
      95,   95, 0x0,    5,  666,
     107,  107, 0x0,    3,  676,
     116,  116, 0x0,    3,  682,

 // enum data: key, value
     124, uint(QmlAVPlayer::Infinite),
     126, uint(QmlAVPlayer::PositionMax),
     127, uint(QmlAVPlayer::StoppedState),
     128, uint(QmlAVPlayer::PlayingState),
     129, uint(QmlAVPlayer::PausedState),
     130, uint(QmlAVPlayer::UnknownStatus),
     131, uint(QmlAVPlayer::NoMedia),
     132, uint(QmlAVPlayer::Loading),
     133, uint(QmlAVPlayer::Loaded),
     134, uint(QmlAVPlayer::Stalled),
     135, uint(QmlAVPlayer::Buffering),
     136, uint(QmlAVPlayer::Buffered),
     137, uint(QmlAVPlayer::EndOfMedia),
     138, uint(QmlAVPlayer::InvalidMedia),
     139, uint(QmlAVPlayer::NoError),
     140, uint(QmlAVPlayer::ResourceError),
     141, uint(QmlAVPlayer::FormatError),
     142, uint(QmlAVPlayer::NetworkError),
     143, uint(QmlAVPlayer::AccessDenied),
     144, uint(QmlAVPlayer::ServiceMissing),
     145, uint(QmlAVPlayer::ChannelLayoutAuto),
     146, uint(QmlAVPlayer::Left),
     147, uint(QmlAVPlayer::Right),
     148, uint(QmlAVPlayer::Mono),
     149, uint(QmlAVPlayer::Stereo),
     150, uint(QmlAVPlayer::BufferTime),
     151, uint(QmlAVPlayer::BufferBytes),
     152, uint(QmlAVPlayer::BufferPackets),
     153, uint(QmlAVPlayer::MediaEndAction_Default),
     154, uint(QmlAVPlayer::MediaEndAction_KeepDisplay),
     155, uint(QmlAVPlayer::MediaEndAction_Pause),

       0        // eod
};

void QmlAVPlayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QmlAVPlayer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->volumeChanged(); break;
        case 1: _t->mutedChanged(); break;
        case 2: _t->hasAudioChanged(); break;
        case 3: _t->hasVideoChanged(); break;
        case 4: _t->durationChanged(); break;
        case 5: _t->positionChanged(); break;
        case 6: _t->sourceChanged(); break;
        case 7: _t->autoLoadChanged(); break;
        case 8: _t->loopCountChanged(); break;
        case 9: _t->videoOutChanged(); break;
        case 10: _t->playbackStateChanged(); break;
        case 11: _t->autoPlayChanged(); break;
        case 12: _t->playbackRateChanged(); break;
        case 13: _t->paused(); break;
        case 14: _t->stopped(); break;
        case 15: _t->playing(); break;
        case 16: _t->startPositionChanged(); break;
        case 17: _t->stopPositionChanged(); break;
        case 18: _t->seekableChanged(); break;
        case 19: _t->seekFinished(); break;
        case 20: _t->fastSeekChanged(); break;
        case 21: _t->bufferProgressChanged(); break;
        case 22: _t->videoCodecPriorityChanged(); break;
        case 23: _t->videoCodecOptionsChanged(); break;
        case 24: _t->avFormatOptionsChanged(); break;
        case 25: _t->useWallclockAsTimestampsChanged(); break;
        case 26: _t->channelLayoutChanged(); break;
        case 27: _t->timeoutChanged(); break;
        case 28: _t->abortOnTimeoutChanged(); break;
        case 29: _t->audioTrackChanged(); break;
        case 30: _t->internalAudioTracksChanged(); break;
        case 31: _t->videoTrackChanged(); break;
        case 32: _t->internalVideoTracksChanged(); break;
        case 33: _t->externalAudioChanged(); break;
        case 34: _t->externalAudioTracksChanged(); break;
        case 35: _t->internalSubtitleTrackChanged(); break;
        case 36: _t->internalSubtitleTracksChanged(); break;
        case 37: _t->bufferSizeChanged(); break;
        case 38: _t->bufferModeChanged(); break;
        case 39: _t->frameRateChanged(); break;
        case 40: _t->mediaEndActionChanged(); break;
        case 41: _t->errorChanged(); break;
        case 42: _t->error((*reinterpret_cast< Error(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 43: _t->statusChanged(); break;
        case 44: _t->mediaObjectChanged(); break;
        case 45: _t->audioBackendsChanged(); break;
        case 46: _t->play(); break;
        case 47: _t->pause(); break;
        case 48: _t->stop(); break;
        case 49: _t->stepForward(); break;
        case 50: _t->stepBackward(); break;
        case 51: _t->seek((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 52: _t->seekForward(); break;
        case 53: _t->seekBackward(); break;
        case 54: _t->_q_error((*reinterpret_cast< const QtAV::AVError(*)>(_a[1]))); break;
        case 55: _t->_q_statusChanged(); break;
        case 56: _t->_q_started(); break;
        case 57: _t->_q_stopped(); break;
        case 58: _t->_q_paused((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 59: _t->applyVolume(); break;
        case 60: _t->applyChannelLayout(); break;
        case 61: _t->play((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 54:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QtAV::AVError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::volumeChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::mutedChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::hasAudioChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::hasVideoChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::durationChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::positionChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::sourceChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::autoLoadChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::loopCountChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::videoOutChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::playbackStateChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::autoPlayChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::playbackRateChanged)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::paused)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::stopped)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::playing)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::startPositionChanged)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::stopPositionChanged)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::seekableChanged)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::seekFinished)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::fastSeekChanged)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::bufferProgressChanged)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::videoCodecPriorityChanged)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::videoCodecOptionsChanged)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::avFormatOptionsChanged)) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::useWallclockAsTimestampsChanged)) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::channelLayoutChanged)) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::timeoutChanged)) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::abortOnTimeoutChanged)) {
                *result = 28;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::audioTrackChanged)) {
                *result = 29;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::internalAudioTracksChanged)) {
                *result = 30;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::videoTrackChanged)) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::internalVideoTracksChanged)) {
                *result = 32;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::externalAudioChanged)) {
                *result = 33;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::externalAudioTracksChanged)) {
                *result = 34;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::internalSubtitleTrackChanged)) {
                *result = 35;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::internalSubtitleTracksChanged)) {
                *result = 36;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::bufferSizeChanged)) {
                *result = 37;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::bufferModeChanged)) {
                *result = 38;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::frameRateChanged)) {
                *result = 39;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::mediaEndActionChanged)) {
                *result = 40;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::errorChanged)) {
                *result = 41;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)(Error , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::error)) {
                *result = 42;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::statusChanged)) {
                *result = 43;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::mediaObjectChanged)) {
                *result = 44;
                return;
            }
        }
        {
            using _t = void (QmlAVPlayer::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QmlAVPlayer::audioBackendsChanged)) {
                *result = 45;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 16:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< MediaMetaData* >(); break;
        case 30:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QtAV::VideoCapture* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QmlAVPlayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qreal*>(_v) = _t->volume(); break;
        case 1: *reinterpret_cast< Status*>(_v) = _t->status(); break;
        case 2: *reinterpret_cast< Error*>(_v) = _t->error(); break;
        case 3: *reinterpret_cast< int*>(_v) = _t->duration(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->position(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->isMuted(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->hasAudio(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->hasVideo(); break;
        case 8: *reinterpret_cast< PlaybackState*>(_v) = _t->playbackState(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->autoPlay(); break;
        case 10: *reinterpret_cast< bool*>(_v) = _t->isAutoLoad(); break;
        case 11: *reinterpret_cast< qreal*>(_v) = _t->playbackRate(); break;
        case 12: *reinterpret_cast< QUrl*>(_v) = _t->source(); break;
        case 13: *reinterpret_cast< int*>(_v) = _t->loopCount(); break;
        case 14: *reinterpret_cast< qreal*>(_v) = _t->bufferProgress(); break;
        case 15: *reinterpret_cast< bool*>(_v) = _t->isSeekable(); break;
        case 16: *reinterpret_cast< MediaMetaData**>(_v) = _t->metaData(); break;
        case 17: *reinterpret_cast< QObject**>(_v) = _t->mediaObject(); break;
        case 18: *reinterpret_cast< QString*>(_v) = _t->errorString(); break;
        case 19: *reinterpret_cast< int*>(_v) = _t->startPosition(); break;
        case 20: *reinterpret_cast< int*>(_v) = _t->stopPosition(); break;
        case 21: *reinterpret_cast< bool*>(_v) = _t->isFastSeek(); break;
        case 22: *reinterpret_cast< int*>(_v) = _t->timeout(); break;
        case 23: *reinterpret_cast< bool*>(_v) = _t->abortOnTimeout(); break;
        case 24: *reinterpret_cast< ChannelLayout*>(_v) = _t->channelLayout(); break;
        case 25: *reinterpret_cast< QStringList*>(_v) = _t->videoCodecs(); break;
        case 26: *reinterpret_cast< QStringList*>(_v) = _t->videoCodecPriority(); break;
        case 27: *reinterpret_cast< QVariantMap*>(_v) = _t->videoCodecOptions(); break;
        case 28: *reinterpret_cast< QVariantMap*>(_v) = _t->avFormatOptions(); break;
        case 29: *reinterpret_cast< bool*>(_v) = _t->useWallclockAsTimestamps(); break;
        case 30: *reinterpret_cast< QtAV::VideoCapture**>(_v) = _t->videoCapture(); break;
        case 31: *reinterpret_cast< int*>(_v) = _t->audioTrack(); break;
        case 32: *reinterpret_cast< int*>(_v) = _t->videoTrack(); break;
        case 33: *reinterpret_cast< int*>(_v) = _t->bufferSize(); break;
        case 34: *reinterpret_cast< BufferMode*>(_v) = _t->bufferMode(); break;
        case 35: *reinterpret_cast< qreal*>(_v) = _t->frameRate(); break;
        case 36: *reinterpret_cast< QUrl*>(_v) = _t->externalAudio(); break;
        case 37: *reinterpret_cast< QVariantList*>(_v) = _t->internalAudioTracks(); break;
        case 38: *reinterpret_cast< QVariantList*>(_v) = _t->internalVideoTracks(); break;
        case 39: *reinterpret_cast< QVariantList*>(_v) = _t->externalAudioTracks(); break;
        case 40: *reinterpret_cast< QVariantList*>(_v) = _t->internalSubtitleTracks(); break;
        case 41: *reinterpret_cast< int*>(_v) = _t->internalSubtitleTrack(); break;
        case 42: *reinterpret_cast< MediaEndAction*>(_v) = _t->mediaEndAction(); break;
        case 43: *reinterpret_cast< QQmlListProperty<QuickAudioFilter>*>(_v) = _t->audioFilters(); break;
        case 44: *reinterpret_cast< QQmlListProperty<QuickVideoFilter>*>(_v) = _t->videoFilters(); break;
        case 45: *reinterpret_cast< QStringList*>(_v) = _t->audioBackends(); break;
        case 46: *reinterpret_cast< QStringList*>(_v) = _t->supportedAudioBackends(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QmlAVPlayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setVolume(*reinterpret_cast< qreal*>(_v)); break;
        case 5: _t->setMuted(*reinterpret_cast< bool*>(_v)); break;
        case 9: _t->setAutoPlay(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setAutoLoad(*reinterpret_cast< bool*>(_v)); break;
        case 11: _t->setPlaybackRate(*reinterpret_cast< qreal*>(_v)); break;
        case 12: _t->setSource(*reinterpret_cast< QUrl*>(_v)); break;
        case 13: _t->setLoopCount(*reinterpret_cast< int*>(_v)); break;
        case 19: _t->setStartPosition(*reinterpret_cast< int*>(_v)); break;
        case 20: _t->setStopPosition(*reinterpret_cast< int*>(_v)); break;
        case 21: _t->setFastSeek(*reinterpret_cast< bool*>(_v)); break;
        case 22: _t->setTimeout(*reinterpret_cast< int*>(_v)); break;
        case 23: _t->setAbortOnTimeout(*reinterpret_cast< bool*>(_v)); break;
        case 24: _t->setChannelLayout(*reinterpret_cast< ChannelLayout*>(_v)); break;
        case 26: _t->setVideoCodecPriority(*reinterpret_cast< QStringList*>(_v)); break;
        case 27: _t->setVideoCodecOptions(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 28: _t->setAVFormatOptions(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 29: _t->setWallclockAsTimestamps(*reinterpret_cast< bool*>(_v)); break;
        case 31: _t->setAudioTrack(*reinterpret_cast< int*>(_v)); break;
        case 32: _t->setVideoTrack(*reinterpret_cast< int*>(_v)); break;
        case 33: _t->setBufferSize(*reinterpret_cast< int*>(_v)); break;
        case 34: _t->setBufferMode(*reinterpret_cast< BufferMode*>(_v)); break;
        case 35: _t->setFrameRate(*reinterpret_cast< qreal*>(_v)); break;
        case 36: _t->setExternalAudio(*reinterpret_cast< QUrl*>(_v)); break;
        case 41: _t->setInternalSubtitleTrack(*reinterpret_cast< int*>(_v)); break;
        case 42: _t->setMediaEndAction(*reinterpret_cast< MediaEndAction*>(_v)); break;
        case 45: _t->setAudioBackends(*reinterpret_cast< QStringList*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QmlAVPlayer::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_QmlAVPlayer.data,
    qt_meta_data_QmlAVPlayer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QmlAVPlayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QmlAVPlayer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QmlAVPlayer.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QQmlParserStatus"))
        return static_cast< QQmlParserStatus*>(this);
    if (!strcmp(_clname, "org.qt-project.Qt.QQmlParserStatus"))
        return static_cast< QQmlParserStatus*>(this);
    return QObject::qt_metacast(_clname);
}

int QmlAVPlayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 47;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 47;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 47;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 47;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 47;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QmlAVPlayer::volumeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QmlAVPlayer::mutedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QmlAVPlayer::hasAudioChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QmlAVPlayer::hasVideoChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QmlAVPlayer::durationChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void QmlAVPlayer::positionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QmlAVPlayer::sourceChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void QmlAVPlayer::autoLoadChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void QmlAVPlayer::loopCountChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void QmlAVPlayer::videoOutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void QmlAVPlayer::playbackStateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void QmlAVPlayer::autoPlayChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void QmlAVPlayer::playbackRateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void QmlAVPlayer::paused()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void QmlAVPlayer::stopped()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void QmlAVPlayer::playing()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void QmlAVPlayer::startPositionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}

// SIGNAL 17
void QmlAVPlayer::stopPositionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 17, nullptr);
}

// SIGNAL 18
void QmlAVPlayer::seekableChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}

// SIGNAL 19
void QmlAVPlayer::seekFinished()
{
    QMetaObject::activate(this, &staticMetaObject, 19, nullptr);
}

// SIGNAL 20
void QmlAVPlayer::fastSeekChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 20, nullptr);
}

// SIGNAL 21
void QmlAVPlayer::bufferProgressChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 21, nullptr);
}

// SIGNAL 22
void QmlAVPlayer::videoCodecPriorityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 22, nullptr);
}

// SIGNAL 23
void QmlAVPlayer::videoCodecOptionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 23, nullptr);
}

// SIGNAL 24
void QmlAVPlayer::avFormatOptionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 24, nullptr);
}

// SIGNAL 25
void QmlAVPlayer::useWallclockAsTimestampsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 25, nullptr);
}

// SIGNAL 26
void QmlAVPlayer::channelLayoutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 26, nullptr);
}

// SIGNAL 27
void QmlAVPlayer::timeoutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 27, nullptr);
}

// SIGNAL 28
void QmlAVPlayer::abortOnTimeoutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 28, nullptr);
}

// SIGNAL 29
void QmlAVPlayer::audioTrackChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 29, nullptr);
}

// SIGNAL 30
void QmlAVPlayer::internalAudioTracksChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 30, nullptr);
}

// SIGNAL 31
void QmlAVPlayer::videoTrackChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 31, nullptr);
}

// SIGNAL 32
void QmlAVPlayer::internalVideoTracksChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 32, nullptr);
}

// SIGNAL 33
void QmlAVPlayer::externalAudioChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 33, nullptr);
}

// SIGNAL 34
void QmlAVPlayer::externalAudioTracksChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 34, nullptr);
}

// SIGNAL 35
void QmlAVPlayer::internalSubtitleTrackChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 35, nullptr);
}

// SIGNAL 36
void QmlAVPlayer::internalSubtitleTracksChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 36, nullptr);
}

// SIGNAL 37
void QmlAVPlayer::bufferSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 37, nullptr);
}

// SIGNAL 38
void QmlAVPlayer::bufferModeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 38, nullptr);
}

// SIGNAL 39
void QmlAVPlayer::frameRateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 39, nullptr);
}

// SIGNAL 40
void QmlAVPlayer::mediaEndActionChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 40, nullptr);
}

// SIGNAL 41
void QmlAVPlayer::errorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 41, nullptr);
}

// SIGNAL 42
void QmlAVPlayer::error(Error _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 42, _a);
}

// SIGNAL 43
void QmlAVPlayer::statusChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 43, nullptr);
}

// SIGNAL 44
void QmlAVPlayer::mediaObjectChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 44, nullptr);
}

// SIGNAL 45
void QmlAVPlayer::audioBackendsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 45, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
