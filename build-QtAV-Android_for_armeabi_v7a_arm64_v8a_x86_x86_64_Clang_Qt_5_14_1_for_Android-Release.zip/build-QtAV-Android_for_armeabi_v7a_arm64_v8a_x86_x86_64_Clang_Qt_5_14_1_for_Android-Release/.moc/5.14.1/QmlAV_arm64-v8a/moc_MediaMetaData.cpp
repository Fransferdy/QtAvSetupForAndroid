/****************************************************************************
** Meta object code from reading C++ file 'MediaMetaData.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtAV/qml/QmlAV/MediaMetaData.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MediaMetaData.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MediaMetaData_t {
    QByteArrayData data[108];
    char stringdata0[1175];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MediaMetaData_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MediaMetaData_t qt_meta_stringdata_MediaMetaData = {
    {
QT_MOC_LITERAL(0, 0, 13), // "MediaMetaData"
QT_MOC_LITERAL(1, 14, 15), // "metaDataChanged"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 5), // "title"
QT_MOC_LITERAL(4, 37, 8), // "subTitle"
QT_MOC_LITERAL(5, 46, 6), // "author"
QT_MOC_LITERAL(6, 53, 7), // "comment"
QT_MOC_LITERAL(7, 61, 11), // "description"
QT_MOC_LITERAL(8, 73, 8), // "category"
QT_MOC_LITERAL(9, 82, 5), // "genre"
QT_MOC_LITERAL(10, 88, 4), // "year"
QT_MOC_LITERAL(11, 93, 4), // "date"
QT_MOC_LITERAL(12, 98, 10), // "userRating"
QT_MOC_LITERAL(13, 109, 8), // "keywords"
QT_MOC_LITERAL(14, 118, 8), // "language"
QT_MOC_LITERAL(15, 127, 9), // "publisher"
QT_MOC_LITERAL(16, 137, 9), // "copyright"
QT_MOC_LITERAL(17, 147, 14), // "parentalRating"
QT_MOC_LITERAL(18, 162, 18), // "ratingOrganization"
QT_MOC_LITERAL(19, 181, 4), // "size"
QT_MOC_LITERAL(20, 186, 9), // "mediaType"
QT_MOC_LITERAL(21, 196, 8), // "duration"
QT_MOC_LITERAL(22, 205, 9), // "startTime"
QT_MOC_LITERAL(23, 215, 12), // "audioBitRate"
QT_MOC_LITERAL(24, 228, 10), // "audioCodec"
QT_MOC_LITERAL(25, 239, 12), // "averageLevel"
QT_MOC_LITERAL(26, 252, 12), // "channelCount"
QT_MOC_LITERAL(27, 265, 13), // "channelLayout"
QT_MOC_LITERAL(28, 279, 9), // "peakValue"
QT_MOC_LITERAL(29, 289, 12), // "sampleFormat"
QT_MOC_LITERAL(30, 302, 10), // "sampleRate"
QT_MOC_LITERAL(31, 313, 10), // "albumTitle"
QT_MOC_LITERAL(32, 324, 11), // "albumArtist"
QT_MOC_LITERAL(33, 336, 18), // "contributingArtist"
QT_MOC_LITERAL(34, 355, 8), // "composer"
QT_MOC_LITERAL(35, 364, 9), // "conductor"
QT_MOC_LITERAL(36, 374, 6), // "lyrics"
QT_MOC_LITERAL(37, 381, 4), // "mood"
QT_MOC_LITERAL(38, 386, 11), // "trackNumber"
QT_MOC_LITERAL(39, 398, 10), // "trackCount"
QT_MOC_LITERAL(40, 409, 16), // "coverArtUrlSmall"
QT_MOC_LITERAL(41, 426, 16), // "coverArtUrlLarge"
QT_MOC_LITERAL(42, 443, 10), // "resolution"
QT_MOC_LITERAL(43, 454, 16), // "pixelAspectRatio"
QT_MOC_LITERAL(44, 471, 14), // "videoFrameRate"
QT_MOC_LITERAL(45, 486, 12), // "videoBitRate"
QT_MOC_LITERAL(46, 499, 10), // "videoCodec"
QT_MOC_LITERAL(47, 510, 11), // "pixelFormat"
QT_MOC_LITERAL(48, 522, 11), // "videoFrames"
QT_MOC_LITERAL(49, 534, 9), // "posterUrl"
QT_MOC_LITERAL(50, 544, 13), // "chapterNumber"
QT_MOC_LITERAL(51, 558, 8), // "director"
QT_MOC_LITERAL(52, 567, 13), // "leadPerformer"
QT_MOC_LITERAL(53, 581, 6), // "writer"
QT_MOC_LITERAL(54, 588, 3), // "Key"
QT_MOC_LITERAL(55, 592, 5), // "Title"
QT_MOC_LITERAL(56, 598, 8), // "SubTitle"
QT_MOC_LITERAL(57, 607, 6), // "Author"
QT_MOC_LITERAL(58, 614, 7), // "Comment"
QT_MOC_LITERAL(59, 622, 11), // "Description"
QT_MOC_LITERAL(60, 634, 8), // "Category"
QT_MOC_LITERAL(61, 643, 5), // "Genre"
QT_MOC_LITERAL(62, 649, 4), // "Year"
QT_MOC_LITERAL(63, 654, 4), // "Date"
QT_MOC_LITERAL(64, 659, 10), // "UserRating"
QT_MOC_LITERAL(65, 670, 8), // "Keywords"
QT_MOC_LITERAL(66, 679, 8), // "Language"
QT_MOC_LITERAL(67, 688, 9), // "Publisher"
QT_MOC_LITERAL(68, 698, 9), // "Copyright"
QT_MOC_LITERAL(69, 708, 14), // "ParentalRating"
QT_MOC_LITERAL(70, 723, 18), // "RatingOrganization"
QT_MOC_LITERAL(71, 742, 4), // "Size"
QT_MOC_LITERAL(72, 747, 9), // "MediaType"
QT_MOC_LITERAL(73, 757, 8), // "Duration"
QT_MOC_LITERAL(74, 766, 9), // "StartTime"
QT_MOC_LITERAL(75, 776, 12), // "AudioBitRate"
QT_MOC_LITERAL(76, 789, 10), // "AudioCodec"
QT_MOC_LITERAL(77, 800, 12), // "AverageLevel"
QT_MOC_LITERAL(78, 813, 12), // "ChannelCount"
QT_MOC_LITERAL(79, 826, 9), // "PeakValue"
QT_MOC_LITERAL(80, 836, 10), // "SampleRate"
QT_MOC_LITERAL(81, 847, 12), // "SampleFormat"
QT_MOC_LITERAL(82, 860, 13), // "ChannelLayout"
QT_MOC_LITERAL(83, 874, 10), // "AlbumTitle"
QT_MOC_LITERAL(84, 885, 11), // "AlbumArtist"
QT_MOC_LITERAL(85, 897, 18), // "ContributingArtist"
QT_MOC_LITERAL(86, 916, 8), // "Composer"
QT_MOC_LITERAL(87, 925, 9), // "Conductor"
QT_MOC_LITERAL(88, 935, 6), // "Lyrics"
QT_MOC_LITERAL(89, 942, 4), // "Mood"
QT_MOC_LITERAL(90, 947, 11), // "TrackNumber"
QT_MOC_LITERAL(91, 959, 10), // "TrackCount"
QT_MOC_LITERAL(92, 970, 16), // "CoverArtUrlSmall"
QT_MOC_LITERAL(93, 987, 16), // "CoverArtUrlLarge"
QT_MOC_LITERAL(94, 1004, 10), // "Resolution"
QT_MOC_LITERAL(95, 1015, 16), // "PixelAspectRatio"
QT_MOC_LITERAL(96, 1032, 14), // "VideoFrameRate"
QT_MOC_LITERAL(97, 1047, 12), // "VideoBitRate"
QT_MOC_LITERAL(98, 1060, 10), // "VideoCodec"
QT_MOC_LITERAL(99, 1071, 11), // "PixelFormat"
QT_MOC_LITERAL(100, 1083, 11), // "VideoFrames"
QT_MOC_LITERAL(101, 1095, 9), // "PosterUrl"
QT_MOC_LITERAL(102, 1105, 13), // "ChapterNumber"
QT_MOC_LITERAL(103, 1119, 8), // "Director"
QT_MOC_LITERAL(104, 1128, 13), // "LeadPerformer"
QT_MOC_LITERAL(105, 1142, 6), // "Writer"
QT_MOC_LITERAL(106, 1149, 11), // "PosterImage"
QT_MOC_LITERAL(107, 1161, 13) // "CoverArtImage"

    },
    "MediaMetaData\0metaDataChanged\0\0title\0"
    "subTitle\0author\0comment\0description\0"
    "category\0genre\0year\0date\0userRating\0"
    "keywords\0language\0publisher\0copyright\0"
    "parentalRating\0ratingOrganization\0"
    "size\0mediaType\0duration\0startTime\0"
    "audioBitRate\0audioCodec\0averageLevel\0"
    "channelCount\0channelLayout\0peakValue\0"
    "sampleFormat\0sampleRate\0albumTitle\0"
    "albumArtist\0contributingArtist\0composer\0"
    "conductor\0lyrics\0mood\0trackNumber\0"
    "trackCount\0coverArtUrlSmall\0"
    "coverArtUrlLarge\0resolution\0"
    "pixelAspectRatio\0videoFrameRate\0"
    "videoBitRate\0videoCodec\0pixelFormat\0"
    "videoFrames\0posterUrl\0chapterNumber\0"
    "director\0leadPerformer\0writer\0Key\0"
    "Title\0SubTitle\0Author\0Comment\0Description\0"
    "Category\0Genre\0Year\0Date\0UserRating\0"
    "Keywords\0Language\0Publisher\0Copyright\0"
    "ParentalRating\0RatingOrganization\0"
    "Size\0MediaType\0Duration\0StartTime\0"
    "AudioBitRate\0AudioCodec\0AverageLevel\0"
    "ChannelCount\0PeakValue\0SampleRate\0"
    "SampleFormat\0ChannelLayout\0AlbumTitle\0"
    "AlbumArtist\0ContributingArtist\0Composer\0"
    "Conductor\0Lyrics\0Mood\0TrackNumber\0"
    "TrackCount\0CoverArtUrlSmall\0"
    "CoverArtUrlLarge\0Resolution\0"
    "PixelAspectRatio\0VideoFrameRate\0"
    "VideoBitRate\0VideoCodec\0PixelFormat\0"
    "VideoFrames\0PosterUrl\0ChapterNumber\0"
    "Director\0LeadPerformer\0Writer\0PosterImage\0"
    "CoverArtImage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MediaMetaData[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
      51,   20, // properties
       1,  224, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,

 // properties: name, type, flags
       3, QMetaType::QVariant, 0x00495001,
       4, QMetaType::QVariant, 0x00495001,
       5, QMetaType::QVariant, 0x00495001,
       6, QMetaType::QVariant, 0x00495001,
       7, QMetaType::QVariant, 0x00495001,
       8, QMetaType::QVariant, 0x00495001,
       9, QMetaType::QVariant, 0x00495001,
      10, QMetaType::QVariant, 0x00495001,
      11, QMetaType::QVariant, 0x00495001,
      12, QMetaType::QVariant, 0x00495001,
      13, QMetaType::QVariant, 0x00495001,
      14, QMetaType::QVariant, 0x00495001,
      15, QMetaType::QVariant, 0x00495001,
      16, QMetaType::QVariant, 0x00495001,
      17, QMetaType::QVariant, 0x00495001,
      18, QMetaType::QVariant, 0x00495001,
      19, QMetaType::QVariant, 0x00495001,
      20, QMetaType::QVariant, 0x00495001,
      21, QMetaType::QVariant, 0x00495001,
      22, QMetaType::QVariant, 0x00495001,
      23, QMetaType::QVariant, 0x00495001,
      24, QMetaType::QVariant, 0x00495001,
      25, QMetaType::QVariant, 0x00495001,
      26, QMetaType::QVariant, 0x00495001,
      27, QMetaType::QVariant, 0x00495001,
      28, QMetaType::QVariant, 0x00495001,
      29, QMetaType::QVariant, 0x00495001,
      30, QMetaType::QVariant, 0x00495001,
      31, QMetaType::QVariant, 0x00495001,
      32, QMetaType::QVariant, 0x00495001,
      33, QMetaType::QVariant, 0x00495001,
      34, QMetaType::QVariant, 0x00495001,
      35, QMetaType::QVariant, 0x00495001,
      36, QMetaType::QVariant, 0x00495001,
      37, QMetaType::QVariant, 0x00495001,
      38, QMetaType::QVariant, 0x00495001,
      39, QMetaType::QVariant, 0x00495001,
      40, QMetaType::QVariant, 0x00495001,
      41, QMetaType::QVariant, 0x00495001,
      42, QMetaType::QVariant, 0x00495001,
      43, QMetaType::QVariant, 0x00495001,
      44, QMetaType::QVariant, 0x00495001,
      45, QMetaType::QVariant, 0x00495001,
      46, QMetaType::QVariant, 0x00495001,
      47, QMetaType::QVariant, 0x00495001,
      48, QMetaType::QVariant, 0x00495001,
      49, QMetaType::QVariant, 0x00495001,
      50, QMetaType::QVariant, 0x00495001,
      51, QMetaType::QVariant, 0x00495001,
      52, QMetaType::QVariant, 0x00495001,
      53, QMetaType::QVariant, 0x00495001,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,

 // enums: name, alias, flags, count, data
      54,   54, 0x0,   53,  229,

 // enum data: key, value
      55, uint(MediaMetaData::Title),
      56, uint(MediaMetaData::SubTitle),
      57, uint(MediaMetaData::Author),
      58, uint(MediaMetaData::Comment),
      59, uint(MediaMetaData::Description),
      60, uint(MediaMetaData::Category),
      61, uint(MediaMetaData::Genre),
      62, uint(MediaMetaData::Year),
      63, uint(MediaMetaData::Date),
      64, uint(MediaMetaData::UserRating),
      65, uint(MediaMetaData::Keywords),
      66, uint(MediaMetaData::Language),
      67, uint(MediaMetaData::Publisher),
      68, uint(MediaMetaData::Copyright),
      69, uint(MediaMetaData::ParentalRating),
      70, uint(MediaMetaData::RatingOrganization),
      71, uint(MediaMetaData::Size),
      72, uint(MediaMetaData::MediaType),
      73, uint(MediaMetaData::Duration),
      74, uint(MediaMetaData::StartTime),
      75, uint(MediaMetaData::AudioBitRate),
      76, uint(MediaMetaData::AudioCodec),
      77, uint(MediaMetaData::AverageLevel),
      78, uint(MediaMetaData::ChannelCount),
      79, uint(MediaMetaData::PeakValue),
      80, uint(MediaMetaData::SampleRate),
      81, uint(MediaMetaData::SampleFormat),
      82, uint(MediaMetaData::ChannelLayout),
      83, uint(MediaMetaData::AlbumTitle),
      84, uint(MediaMetaData::AlbumArtist),
      85, uint(MediaMetaData::ContributingArtist),
      86, uint(MediaMetaData::Composer),
      87, uint(MediaMetaData::Conductor),
      88, uint(MediaMetaData::Lyrics),
      89, uint(MediaMetaData::Mood),
      90, uint(MediaMetaData::TrackNumber),
      91, uint(MediaMetaData::TrackCount),
      92, uint(MediaMetaData::CoverArtUrlSmall),
      93, uint(MediaMetaData::CoverArtUrlLarge),
      94, uint(MediaMetaData::Resolution),
      95, uint(MediaMetaData::PixelAspectRatio),
      96, uint(MediaMetaData::VideoFrameRate),
      97, uint(MediaMetaData::VideoBitRate),
      98, uint(MediaMetaData::VideoCodec),
      99, uint(MediaMetaData::PixelFormat),
     100, uint(MediaMetaData::VideoFrames),
     101, uint(MediaMetaData::PosterUrl),
     102, uint(MediaMetaData::ChapterNumber),
     103, uint(MediaMetaData::Director),
     104, uint(MediaMetaData::LeadPerformer),
     105, uint(MediaMetaData::Writer),
     106, uint(MediaMetaData::PosterImage),
     107, uint(MediaMetaData::CoverArtImage),

       0        // eod
};

void MediaMetaData::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MediaMetaData *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->metaDataChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MediaMetaData::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MediaMetaData::metaDataChanged)) {
                *result = 0;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<MediaMetaData *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QVariant*>(_v) = _t->title(); break;
        case 1: *reinterpret_cast< QVariant*>(_v) = _t->subTitle(); break;
        case 2: *reinterpret_cast< QVariant*>(_v) = _t->author(); break;
        case 3: *reinterpret_cast< QVariant*>(_v) = _t->comment(); break;
        case 4: *reinterpret_cast< QVariant*>(_v) = _t->description(); break;
        case 5: *reinterpret_cast< QVariant*>(_v) = _t->category(); break;
        case 6: *reinterpret_cast< QVariant*>(_v) = _t->genre(); break;
        case 7: *reinterpret_cast< QVariant*>(_v) = _t->year(); break;
        case 8: *reinterpret_cast< QVariant*>(_v) = _t->date(); break;
        case 9: *reinterpret_cast< QVariant*>(_v) = _t->userRating(); break;
        case 10: *reinterpret_cast< QVariant*>(_v) = _t->keywords(); break;
        case 11: *reinterpret_cast< QVariant*>(_v) = _t->language(); break;
        case 12: *reinterpret_cast< QVariant*>(_v) = _t->publisher(); break;
        case 13: *reinterpret_cast< QVariant*>(_v) = _t->copyright(); break;
        case 14: *reinterpret_cast< QVariant*>(_v) = _t->parentalRating(); break;
        case 15: *reinterpret_cast< QVariant*>(_v) = _t->ratingOrganization(); break;
        case 16: *reinterpret_cast< QVariant*>(_v) = _t->size(); break;
        case 17: *reinterpret_cast< QVariant*>(_v) = _t->mediaType(); break;
        case 18: *reinterpret_cast< QVariant*>(_v) = _t->duration(); break;
        case 19: *reinterpret_cast< QVariant*>(_v) = _t->startTime(); break;
        case 20: *reinterpret_cast< QVariant*>(_v) = _t->audioBitRate(); break;
        case 21: *reinterpret_cast< QVariant*>(_v) = _t->audioCodec(); break;
        case 22: *reinterpret_cast< QVariant*>(_v) = _t->averageLevel(); break;
        case 23: *reinterpret_cast< QVariant*>(_v) = _t->channelCount(); break;
        case 24: *reinterpret_cast< QVariant*>(_v) = _t->channelLayout(); break;
        case 25: *reinterpret_cast< QVariant*>(_v) = _t->peakValue(); break;
        case 26: *reinterpret_cast< QVariant*>(_v) = _t->sampleFormat(); break;
        case 27: *reinterpret_cast< QVariant*>(_v) = _t->sampleRate(); break;
        case 28: *reinterpret_cast< QVariant*>(_v) = _t->albumTitle(); break;
        case 29: *reinterpret_cast< QVariant*>(_v) = _t->albumArtist(); break;
        case 30: *reinterpret_cast< QVariant*>(_v) = _t->contributingArtist(); break;
        case 31: *reinterpret_cast< QVariant*>(_v) = _t->composer(); break;
        case 32: *reinterpret_cast< QVariant*>(_v) = _t->conductor(); break;
        case 33: *reinterpret_cast< QVariant*>(_v) = _t->lyrics(); break;
        case 34: *reinterpret_cast< QVariant*>(_v) = _t->mood(); break;
        case 35: *reinterpret_cast< QVariant*>(_v) = _t->trackNumber(); break;
        case 36: *reinterpret_cast< QVariant*>(_v) = _t->trackCount(); break;
        case 37: *reinterpret_cast< QVariant*>(_v) = _t->coverArtUrlSmall(); break;
        case 38: *reinterpret_cast< QVariant*>(_v) = _t->coverArtUrlLarge(); break;
        case 39: *reinterpret_cast< QVariant*>(_v) = _t->resolution(); break;
        case 40: *reinterpret_cast< QVariant*>(_v) = _t->pixelAspectRatio(); break;
        case 41: *reinterpret_cast< QVariant*>(_v) = _t->videoFrameRate(); break;
        case 42: *reinterpret_cast< QVariant*>(_v) = _t->videoBitRate(); break;
        case 43: *reinterpret_cast< QVariant*>(_v) = _t->videoCodec(); break;
        case 44: *reinterpret_cast< QVariant*>(_v) = _t->pixelFormat(); break;
        case 45: *reinterpret_cast< QVariant*>(_v) = _t->videoFrames(); break;
        case 46: *reinterpret_cast< QVariant*>(_v) = _t->posterUrl(); break;
        case 47: *reinterpret_cast< QVariant*>(_v) = _t->chapterNumber(); break;
        case 48: *reinterpret_cast< QVariant*>(_v) = _t->director(); break;
        case 49: *reinterpret_cast< QVariant*>(_v) = _t->leadPerformer(); break;
        case 50: *reinterpret_cast< QVariant*>(_v) = _t->writer(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MediaMetaData::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_MediaMetaData.data,
    qt_meta_data_MediaMetaData,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MediaMetaData::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MediaMetaData::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MediaMetaData.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int MediaMetaData::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 51;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void MediaMetaData::metaDataChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
